<!DOCTYPE html>  
<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2 or superior with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="content-type" content="text/html; charset=UTF8mb4">
	<title>REST Web Panel Evolution</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="jquery/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	</head>
	<body>
	
	<div id="statusbar" class="noselect">
	<div class="notification" style="display:none;"></div>
	<div class="controls">
		<button id="play" title="Play or Play Next [p]" accesskey="p"><span>Play</span></button>
        <button id="stop" title="Stop [s]" accesskey="s"><span>Stop</span></button>
        <button class="button deactivated" id="pause" title="Pause [u]" accesskey="u"><span>Pause</span></button>
		<button id="intro" title="Go to Intro [i]" accesskey="i"><span>Intro</span></button>
        <button id="restart" title="Restart [r]" accesskey="r"><span>Restart</span></button>
	</div>
	<div class="nowPlaying">
		<h2 class="artist" id="nowPlayingArtist">-</h2>
		<h1 class="title" id="nowPlayingTitle">-</h1>
		<h2 class="artist" id="nowPlayingYear">-</h2><br>
		<img id="nowPlayingAlbumArt" src="./Album-Art/no_cover_image.jpg" width="150" height="150" style="border-radius: 15px;">
		<img id="nextTrackAlbumArt" src="./Album-Art/no_cover_image.jpg" width="120" height="120" style="border-radius: 15px;">
		<img id="nextTrackAlbumArt2" src="./Album-Art/no_cover_image.jpg" width="100" height="100" style="border-radius: 15px;">
	</div>
    <div class="timing">
		<div class="Intro">Intro</div>
		<div class="IntroNP" id="introNP">00:00:00</div>
		<div class="Outro">Outro</div>
		<div class="countOutroNP" id="countOutroNP">00:00:00</div>
		<div class="Remaining">Remaining</div>
		<div class="countdownNP" id="countdownNP">00:00:00</div>
		<div class="Elapsed">Elapsed</div>
		<div class="npIntro" id="countForwardNP">00:00:00</div>
		<div class="Duration">Duration</div>
		<div class="DurationNP" id="nowPlayingDuration">00:00:00</div><br>
	</div>
</div>
<div id="optionsRow" class="noselect" style="display inline block">

	<div class="NowPlayingAndNextTrack" id="trackInfo"></div>
	<div class="NowPlayingAndNextTrack" id="trackInfo2"></div>
	
	<button class="button deactivated" id="autodj" title="Manual/AutoDJ [m]" accesskey="m">MANUAL</button>
	<button class="button deactivated" id="assisted" title="Assisted/Automated [a]" accesskey="a">ASSISTED</button>
	<button class="button normal" id="clear" title="Delete Playlist [d]" accesskey="d">DEL. PLAYLIST</button>
    <button class="button normal" id="lineinput" title="Microphone-Off/On-air [t]" accesskey="t">MICROPHONE-OFF</button>
</div>
<div class="playlist-container noselect">
	<table id="playlistRows" border="1">
		<input type="hidden" id="currentTrack" data-id="0" data-track="{&quot;Album&quot;:&quot;&quot;,&quot;AlbumArt&quot;:&quot;&quot;,&quot;Artist&quot;:&quot;&quot;,&quot;ArtistPlayed&quot;:&quot;0001-01-01T00:00:00&quot;,&quot;AutoFree&quot;:&quot;false&quot;,&quot;AutoStop&quot;:&quot;false&quot;,&quot;BPM&quot;:&quot;0&quot;,&quot;BuyLink&quot;:&quot;&quot;,&quot;Comments&quot;:&quot;&quot;,&quot;Composer&quot;:&quot;&quot;,&quot;Copyright&quot;:&quot;&quot;,&quot;CountPlayed&quot;:&quot;0&quot;,&quot;CueTimes&quot;:&quot;&quot;,&quot;DatePlayed&quot;:&quot;0001-01-01T00:00:00&quot;,&quot;DateRequested&quot;:&quot;0001-01-01T00:00:00&quot;,&quot;DiscNo&quot;:&quot;0&quot;,&quot;Duration&quot;:&quot;0&quot;,&quot;Elapsed&quot;:&quot;0&quot;,&quot;Enabled&quot;:&quot;false&quot;,&quot;EndDate&quot;:&quot;2002-01-01T00:00:01&quot;,&quot;FadeIn&quot;:&quot;0&quot;,&quot;FadeOut&quot;:&quot;0&quot;,&quot;FadeType&quot;:&quot;0&quot;,&quot;HasHooks&quot;:&quot;false&quot;,&quot;HighPrecision&quot;:&quot;1&quot;,&quot;ID&quot;:&quot;0&quot;,&quot;IDGenre&quot;:&quot;0&quot;,&quot;IDSubcat&quot;:&quot;0&quot;,&quot;Isrc&quot;:&quot;&quot;,&quot;LimitAction&quot;:&quot;0&quot;,&quot;OriginalArtist&quot;:&quot;&quot;,&quot;Path&quot;:&quot;&quot;,&quot;PlayLimit&quot;:&quot;0&quot;,&quot;PlayOnMainMixer&quot;:&quot;false&quot;,&quot;PlayerID&quot;:&quot;0&quot;,&quot;Position&quot;:&quot;0&quot;,&quot;Publisher&quot;:&quot;&quot;,&quot;Remaining&quot;:&quot;0&quot;,&quot;RequestMessage&quot;:&quot;&quot;,&quot;RequestUser&quot;:&quot;&quot;,&quot;StartDate&quot;:&quot;2002-01-01T00:00:01&quot;,&quot;Sweepers&quot;:&quot;&quot;,&quot;Title&quot;:&quot;&quot;,&quot;TrackNo&quot;:&quot;0&quot;,&quot;TrackType&quot;:&quot;Music&quot;,&quot;Weight&quot;:&quot;0&quot;,&quot;WithLoop&quot;:&quot;false&quot;,&quot;Year&quot;:&quot;&quot;,&quot;bCueDuration&quot;:&quot;0&quot;,&quot;bCueEnd&quot;:&quot;0&quot;,&quot;bCueIntro&quot;:&quot;0&quot;,&quot;bCueLoopIn&quot;:&quot;0&quot;,&quot;bCueLoopOut&quot;:&quot;0&quot;,&quot;bCueNext&quot;:&quot;0&quot;,&quot;bCueOutro&quot;:&quot;0&quot;,&quot;bCueStart&quot;:&quot;0&quot;,&quot;bPosition&quot;:&quot;0&quot;,&quot;bcueHookIN&quot;:&quot;0&quot;,&quot;bcueHookOut&quot;:&quot;0&quot;,&quot;cueEnd&quot;:&quot;0&quot;,&quot;cueHookIN&quot;:&quot;0&quot;,&quot;cueHookOut&quot;:&quot;0&quot;,&quot;cueIntro&quot;:&quot;0&quot;,&quot;cueLoopIn&quot;:&quot;0&quot;,&quot;cueLoopOut&quot;:&quot;0&quot;,&quot;cueNext&quot;:&quot;0&quot;,&quot;cueOutro&quot;:&quot;0&quot;,&quot;cueStart&quot;:&quot;0&quot;,&quot;isOverlay&quot;:&quot;0&quot;,&quot;isPodcast&quot;:&quot;0&quot;,&quot;swFirst&quot;:&quot;false&quot;,&quot;swID&quot;:&quot;0&quot;,&quot;swName&quot;:&quot;&quot;,&quot;swPlay&quot;:&quot;0&quot;,&quot;vtID&quot;:&quot;0&quot;,&quot;vtName&quot;:&quot;&quot;,&quot;vtPlay&quot;:&quot;-100&quot;}">
	</table>
</div>
<div class="log" id="thelog"></div>
<div class="overlay"></div>
<script type="text/javascript" src="js/App.js"></script>
</body>
</html>