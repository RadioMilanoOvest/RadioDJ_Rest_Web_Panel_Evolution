<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<!-- <meta http-equiv="refresh" content="10; URL='history_songs_body.php'"> -->
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard 3.0</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>

<?php

//header("Refresh:5");
require_once('serv_inc.php');
date_default_timezone_set($def_timezone);

?>

<?php

$query = "delete FROM `history`";

$result = mysqli_query($con, $query);
	
if (!$result) {
	echo mysqli_error();
	exit;
}

@mysqli_free_result($con, $result);
mysqli_close($con);

header("location: history_songs_body.php");

?>
</body>
</html>

