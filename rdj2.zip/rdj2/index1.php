<?php
    session_start();

    if (!isset($_SESSION['guaranteed_access']) || $_SESSION['guaranteed_access'] !== true) {
        header('Location: login.php');
        exit;
    }
?>
<html>
<head>
	<!-- For use with RadioDJ 1.8.2 or superior with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<link rel="icon" type="image/png" sizes="48x48" href="./images/logo.png">
	<title>REST Web Panel Evolution</title>
</head>
<?php 
			echo "<frameset cols=\"50%,*\" noresize>";
			echo "<frame src=\"index2.php\" name=\"framesxup\" scrolling=\"auto\" framespacing=\"0\" noresize>";
			echo "<frameset rows=\"82%,6%,2%,10%\" frameborder=\"0\" framespacing=\"0\" noresize>";
			echo "<frame src=\"search.php\" name=\"framedxup\" scrolling=\"auto\" framespacing=\"0\" noresize>";
			echo "<frame src=\"tabs.php\" name=\"framedown1\" scrolling=\"no\" framespacing=\"0\" noresize>";
			echo "<frame src=\"history_songs_header.php\" name=\"framedown2\" scrolling=\"no\" framespacing=\"0\" noresize>";
			echo "<frame src=\"history_songs_body.php\" name=\"framedown3\" scrolling=\"yes\" framespacing=\"0\" noresize>";
			echo "<frame src=\"special_thanks.php\" name=\"framedown4\" scrolling=\"no\" framespacing=\"0\" noresize>";
			echo "<frame src=\"donate.php\" name=\"framedown5\" scrolling=\"no\" framespacing=\"0\" noresize>";
?>
</html>