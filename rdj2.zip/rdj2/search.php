<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Rest Web Panel Evolution - Search Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<script src="jquery/jquery.min.js"></script>
	<script type="text/javascript" src="js/SearchApp.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body link="white" alink="white" vlink="white">
<!--<body link="white" alink="white" vlink="white">-->

<?php
session_start();
require_once('serv_inc.php');
date_default_timezone_set($def_timezone);
header('Content-Type: text/html; charset=utf-8');

$_SESSION['count'] = 0;

$targetpage = $_SERVER['SCRIPT_NAME'];
$lastpage; // last page
$limit;
$start;
$srchpath = ""; //search path holder
$srcquery = ""; //search query holder
$stages = 3; 	//how to split the pagination
$page = 1; 		//default page
$search = "";
$search = "$srch"; // hold the search string
//$search = "$srch"; // hold the search string

/* No xss */
$count_played = 2;
if(isset($_GET['CountPlayed'])){
    $_SESSION['CountPlayed'] = $_GET['CountPlayed'];
}
$count_played = isset($_SESSION['CountPlayed']) ? $_SESSION['CountPlayed'] : 2;

$count_played = strip_tags($count_played);

if($count_played < 1 || $count_played > 2){
	$count_played = 2;
}
/* No xss */

/* No xss */
$SongType = 0;
if(isset($_GET['SongType'])){
    $SongType = mysqli_real_escape_string($con, $_GET['SongType']);
	
	$SongType = strip_tags($SongType);
	
	if($SongType < 0 || $SongType > 14 ){
		$SongType = 0;
	}
}
/* No xss */
$GenreType = "any_genre";
if(isset($_GET['GenreType'])){
	$GenreType = mysqli_real_escape_string($con, $_GET['GenreType']);
	
	$GenreType = strip_tags($GenreType);
}
/* No xss */

if(isset($_GET['searchterm'])){
	if($_GET['searchterm'] != "") {
		
		mysqli_set_charset($con, "utf8");
			
		$srch_test = mysqli_real_escape_string($con, $_GET['searchterm']);
		$srch = strip_tags($srch_test);
		
		$srchpath = "&searchterm=$srch";
		$srcquery = "AND (`artist` LIKE '%$srch%' OR `title` LIKE '%$srch%' OR `year` LIKE '%$srch%')";	
	}
}

if(isset($_GET['page'])){
	$page = mysqli_real_escape_string($con, $_GET['page']);
}

if($page){
	$start = ($page - 1) * $limit;
}else{
	$start = 0;
}
 
if($search == ""){
	
	//Get the number of items
	$query0 = "SELECT COUNT(*) as num FROM `songs` WHERE `enabled`=1 AND `song_type`=0 AND count_played >=0 $srcquery";
	$query00 = "SELECT COUNT(*) as num FROM `songs` WHERE `enabled`=1 AND `song_type`=0 AND count_played =0 $srcquery";
	$query000 = "SELECT COUNT(*) as num FROM `songs` JOIN GENRE ON GENRE.ID = SONGS.ID_GENRE WHERE GENRE.NAME ='$GenreType' AND `enabled`=1 AND `song_type`=0 AND count_played >=0 $srcquery";
	$query0000 = "SELECT COUNT(*) as num FROM `songs` JOIN GENRE ON GENRE.ID = SONGS.ID_GENRE WHERE GENRE.NAME ='$GenreType' AND `enabled`=1 AND `song_type`=0 AND count_played =0 $srcquery";
	
	
	// Query SW1
	if($GenreType == "any_genre" && $count_played == 2){$query = $query0;}
	else if ($GenreType == "any_genre" && $count_played == 1){$query = $query00;}
	else if ($GenreType != "any_genre" && $count_played == 2){$query = $query000;}
	else if ($GenreType != "any_genre" && $count_played == 1){$query = $query0000;}
	
	mysqli_set_charset($con, "utf8");
		
	$total_pages = mysqli_fetch_array(mysqli_query($con, $query));
	$total_pages = $total_pages['num'];
	
	/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	//specific query 1 ($srcquery * song_type * count_played >=0)
	$query1 = "SELECT `image`, `id`, `artist`, `title`, SUBSTRING(CUE_TIMES, 4 + INSTR( CUE_TIMES,'INT'), 3) as `intro`, `duration`, `year`, `date_played`, `artist_played` FROM `songs` WHERE `enabled`=1 $srcquery AND `song_type`=$SongType AND count_played>=0 ORDER BY `artist` ASC LIMIT $start, $limit";
	//specific query 2 ($srcquery * song_type * count_played = 0)
	$query2 = "SELECT `image`, `id`, `artist`, `title`, SUBSTRING(CUE_TIMES, 4 + INSTR( CUE_TIMES,'INT'), 3) as `intro`, `duration`, `year`, `date_played`, `artist_played` FROM `songs` WHERE `enabled`=1 $srcquery AND `song_type`=$SongType AND count_played=0 ORDER BY `artist` ASC LIMIT $start, $limit";
	/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	//specific query 3 ($srcquery(fixed) * song_type(variable) * GenreType(variable) * count_played >=0)
	$query3 = "SELECT `image`, `songs`.`id`, `genre`.`name` as `genre`, `artist`, `title`, SUBSTRING(CUE_TIMES, 4 + INSTR( CUE_TIMES,'INT'), 3) as `intro`, `duration`, `year`, `date_played`, `artist_played` FROM `songs` JOIN GENRE ON GENRE.ID = SONGS.ID_GENRE WHERE GENRE.NAME ='$GenreType' $srcquery AND `enabled`=1 AND `song_type`=$SongType AND count_played >=0 ORDER BY `artist` ASC LIMIT $start, $limit";
	//specific query 4 ($srcquery(fixed) * song_type(variable) * GenreType(variable) * count_played =0)
	$query4 = "SELECT `image`, `songs`.`id`, `genre`.`name` as `genre`, `artist`, `title`, SUBSTRING(CUE_TIMES, 4 + INSTR( CUE_TIMES,'INT'), 3) as `intro`, `duration`, `year`, `date_played`, `artist_played` FROM `songs` JOIN GENRE ON GENRE.ID = SONGS.ID_GENRE WHERE GENRE.NAME ='$GenreType' $srcquery AND `enabled`=1 AND `song_type`=$SongType AND count_played =0 ORDER BY `artist` ASC LIMIT $start, $limit";
	/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
	mysqli_set_charset($con, "utf8");
	
/* --------------------------- Query SW2 ----------------------------- */
//echo"<p></p><br><p></p><br><p></p><br><p></p><br><p></p><br>";
//echo "Srch =" . $srch . "<br>";
//echo "Lastpage " . ceil($total_pages/$limit) . "<br>";
//echo "Page: " . $page . "<br>";
//echo "Total Pages: " . $total_pages . "<br>";
//echo "Limit: " . $limit . "<br>";
//echo "Start: " . $start . "<br>";

if($GenreType == "any_genre" && $count_played == 2){
	//echo"<p></p><br><p></p><br><p></p><br><p></p><br><p></p><br> QUERY1;" . $query1;
	$querySelect = $query1;
}
else if($GenreType == "any_genre" && $count_played == 1){
	//echo"<p></p><br><p></p><br><p></p><br><p></p><br><p></p><br> QUERY2;" . $query2;
	$querySelect = $query2;
}
else if($GenreType != "any_genre" && $count_played == 2) {
	//echo "<p></p><br><p></p><br><p></p><br><p></p><br><p></p><br> QUERY3;" . $query3;
	$querySelect = $query3;
}
else if($GenreType != "any_genre" && $count_played == 1) {
	//echo "<p></p><br><p></p><br><p></p><br><p></p><br><p></p><br> QUERY4;" . $query4;
	$querySelect = $query4;
}
/* --------------------------------------------------------------------------------------------- */
	
	$result = mysqli_query($con, $querySelect);
			
//  Search Field Memory 
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['searchterm'])) {
    $_SESSION['searchterm'] = $_GET['searchterm'];
}
	$searchterm = isset($_SESSION['searchterm']) ? $_SESSION['searchterm'] : '';
//  Search Field Memory 

?>
	<!-- BEGIN SEARCH BOX -->
	<div class="search" id="searching" style=" align=center">
	<!-- <form name="input" id="formica" action="<?php $targetpage ?>" method="get" target="framedxup"> -->
	<form name="input" id="formica" action="<?php $targetpage ?>" method="get" target="framedxup" oninput="submitForm()">
	
		  
	
<table border="0">
<tr>
	<td>
		TYPE Artist, Title or Year
	</td>
	<td>
		&nbsp;
	</td>
	<td>
		Genre
	</td>
	<td>
		Count Played
	</td>
	<td>
		Audio Type
	</td>
</tr>
<tr>
	<td>
		<input type="text" id="campo" value="<?php echo "$searchterm"; ?>" autocomplete="on" name="searchterm">
	</td>
	<td>
		<input type="submit" id="button" name="button" value="Search">
	</td>
	<td>
		<!-- GenreType -->
		<select id="sort-item2" name="GenreType" onchange="document.input.submit()">
			<option value="any_genre" <?php if($GenreType == 'any_genre') echo 'selected'; ?>>Any Genre</option>
			<option value="Acapella" <?php if($GenreType == 'Acapella') echo 'selected'; ?>>Acapella</option>
			<option value="Acid" <?php if($GenreType == 'Acid') echo 'selected'; ?>>Acid</option>
			<option value="Acid_Jazz" <?php if($GenreType == 'Acid_Jazz') echo 'selected'; ?>>Acid Jazz</option>
			<option value="Acoustic" <?php if($GenreType == 'Acoustic') echo 'selected'; ?>>Acoustic</option>
			<option value="Alternative" <?php if($GenreType == 'Alternative') echo 'selected'; ?>>Alternative</option>
			<option value="Alternative_Rock" <?php if($GenreType == 'Alternative_Rock') echo 'selected'; ?>>Alternative Rock</option>
			<option value="Ambient" <?php if($GenreType == 'Ambient') echo 'selected'; ?>>Ambient</option>
			<option value="Anime" <?php if($GenreType == 'Anime') echo 'selected'; ?>>Anime</option>
			<option value="Avantgarde" <?php if($GenreType == 'Avantgarde') echo 'selected'; ?>>Avantgarde</option>
			<option value="Ballad" <?php if($GenreType == 'Ballad') echo 'selected'; ?>>Ballad</option>
			<option value="Bass" <?php if($GenreType == 'Bass') echo 'selected'; ?>>Bass</option>
			<option value="Beat" <?php if($GenreType == 'Beat') echo 'selected'; ?>>Beat</option>
			<option value="Bebob" <?php if($GenreType == 'Bebob') echo 'selected'; ?>>Bebob</option>
			<option value="Big_Band" <?php if($GenreType == 'Big_Band') echo 'selected'; ?>>Big Band</option>
			<option value="Black_Metal" <?php if($GenreType == 'Black_Metal') echo 'selected'; ?>>Black Metal</option>
			<option value="Bluegrass" <?php if($GenreType == 'Bluegrass') echo 'selected'; ?>>Bluegrass</option>
			<option value="Blues" <?php if($GenreType == 'Blues') echo 'selected'; ?>>Blues</option>
			<option value="Booty_Bass" <?php if($GenreType == 'Booty_Bass') echo 'selected'; ?>>Booty Bass</option>
			<option value="BritPop" <?php if($GenreType == 'BritPop') echo 'selected'; ?>>BritPop</option>
			<option value="Cabaret" <?php if($GenreType == 'Cabaret') echo 'selected'; ?>>Cabaret</option>
			<option value="Celtic" <?php if($GenreType == 'Celtic') echo 'selected'; ?>>Celtic</option>
			<option value="Chamber_Music" <?php if($GenreType == 'Chamber_Music') echo 'selected'; ?>>Chamber Music</option>
			<option value="Chanson" <?php if($GenreType == 'Chanson') echo 'selected'; ?>>Chanson</option>
			<option value="Chorus" <?php if($GenreType == 'Chorus') echo 'selected'; ?>>Chorus</option>
			<option value="Christian_Gangsta_Rap" <?php if($GenreType == 'Christian_Gangsta_Rap') echo 'selected'; ?>>Christian Gangsta Rap</option>
			<option value="Christian_Rap" <?php if($GenreType == 'Christian_Rap') echo 'selected'; ?>>Christian Rap</option>
			<option value="Christian_Rock" <?php if($GenreType == 'Christian_Rock') echo 'selected'; ?>>Christian Rock</option>
			<option value="Classic_Rock" <?php if($GenreType == 'Classic_Rock') echo 'selected'; ?>>Classic Rock</option>
			<option value="Classical" <?php if($GenreType == 'Classical') echo 'selected'; ?>>Classical</option>
			<option value="Club" <?php if($GenreType == 'Club') echo 'selected'; ?>>Club</option>
			<option value="Club_House" <?php if($GenreType == 'Club_House') echo 'selected'; ?>>Club - House</option>
			<option value="Comedy" <?php if($GenreType == 'Comedy') echo 'selected'; ?>>Comedy</option>
			<option value="Contemporary_Christian" <?php if($GenreType == 'Contemporary_Christian') echo 'selected'; ?>>Contemporary Christian</option>
			<option value="Country" <?php if($GenreType == 'Country') echo 'selected'; ?>>Country</option>
			<option value="Crossover" <?php if($GenreType == 'Crossover') echo 'selected'; ?>>Crossover</option>
			<option value="Cult" <?php if($GenreType == 'Cult') echo 'selected'; ?>>Cult</option>
			<option value="Dance" <?php if($GenreType == 'Dance') echo 'selected'; ?>>Dance</option>
			<option value="Dance_Hall" <?php if($GenreType == 'Dance_Hall') echo 'selected'; ?>>Dance Hall</option>
			<option value="Darkwave" <?php if($GenreType == 'Darkwave') echo 'selected'; ?>>Darkwave</option>
			<option value="Death_Metal" <?php if($GenreType == 'Death_Metal') echo 'selected'; ?>>Death Metal</option>
			<option value="Disco" <?php if($GenreType == 'Disco') echo 'selected'; ?>>Disco</option>
			<option value="Dream" <?php if($GenreType == 'Dream') echo 'selected'; ?>>Dream</option>
			<option value="Drum_&_Bass" <?php if($GenreType == 'Drum_&_Bass') echo 'selected'; ?>>Drum & Bass</option>
			<option value="Drum_Solo" <?php if($GenreType == 'Drum_Solo') echo 'selected'; ?>>Drum Solo</option>
			<option value="Duet" <?php if($GenreType == 'Duet') echo 'selected'; ?>>Duet</option>
			<option value="Easy_Listening" <?php if($GenreType == 'Easy_Listening') echo 'selected'; ?>>Easy Listening</option>
			<option value="Electronic" <?php if($GenreType == 'Electronic') echo 'selected'; ?>>Electronic</option>
			<option value="Ethnic" <?php if($GenreType == 'Ethnic') echo 'selected'; ?>>Ethnic</option>
			<option value="Euro_House" <?php if($GenreType == 'Euro_House') echo 'selected'; ?>>Euro-House</option>
			<option value="Euro_Techno" <?php if($GenreType == 'Euro_Techno') echo 'selected'; ?>>Euro-Techno</option>
			<option value="Eurodance" <?php if($GenreType == 'Eurodance') echo 'selected'; ?>>Eurodance</option>
			<option value="Fast_Fusion" <?php if($GenreType == 'Fast_Fusion') echo 'selected'; ?>>Fast Fusion</option>
			<option value="Folk" <?php if($GenreType == 'Folk') echo 'selected'; ?>>Folk</option>
			<option value="Folk_Rock" <?php if($GenreType == 'Folk_Rock') echo 'selected'; ?>>Folk-Rock</option>
			<option value="Folklore" <?php if($GenreType == 'Folklore') echo 'selected'; ?>>Folklore</option>
			<option value="Freestyle" <?php if($GenreType == 'Freestyle') echo 'selected'; ?>>Freestyle</option>
			<option value="Funk" <?php if($GenreType == 'Funk') echo 'selected'; ?>>Funk</option>
			<option value="Fusion" <?php if($GenreType == 'Fusion') echo 'selected'; ?>>Fusion</option>
			<option value="Game" <?php if($GenreType == 'Game') echo 'selected'; ?>>Game</option>
			<option value="Gangsta" <?php if($GenreType == 'Gangsta') echo 'selected'; ?>>Gangsta</option>
			<option value="Goa" <?php if($GenreType == 'Goa') echo 'selected'; ?>>Goa</option>
			<option value="Gospel" <?php if($GenreType == 'Gospel') echo 'selected'; ?>>Gospel</option>
			<option value="Gothic" <?php if($GenreType == 'Gothic') echo 'selected'; ?>>Gothic</option>
			<option value="Gothic Rock" <?php if($GenreType == 'Gothic Rock') echo 'selected'; ?>>Gothic Rock</option>
			<option value="Grunge" <?php if($GenreType == 'Grunge') echo 'selected'; ?>>Grunge</option>
			<option value="Hard_Rock" <?php if($GenreType == 'Hard_Rock') echo 'selected'; ?>>Hard Rock</option>
			<option value="Hardcore" <?php if($GenreType == 'Hardcore') echo 'selected'; ?>>Hardcore</option>
			<option value="Heavy_Metal" <?php if($GenreType == 'Heavy_Metal') echo 'selected'; ?>>Heavy Metal</option>
			<option value="Hip_Hop" <?php if($GenreType == 'Hip_Hop') echo 'selected'; ?>>Hip-Hop</option>
			<option value="House" <?php if($GenreType == 'House') echo 'selected'; ?>>House</option>
			<option value="Humour" <?php if($GenreType == 'Humour') echo 'selected'; ?>>Humour</option>
			<option value="Indie" <?php if($GenreType == 'Indie') echo 'selected'; ?>>Indie</option>
			<option value="Industrial" <?php if($GenreType == 'Industrial') echo 'selected'; ?>>Industrial</option>
			<option value="Instrumental" <?php if($GenreType == 'Instrumental') echo 'selected'; ?>>Instrumental</option>
			<option value="Instrumental_Pop" <?php if($GenreType == 'Instrumental_Pop') echo 'selected'; ?>>Instrumental Pop</option>
			<option value="Instrumental_Rock" <?php if($GenreType == 'Instrumental_Rock') echo 'selected'; ?>>Instrumental Rock</option>
			<option value="JPop" <?php if($GenreType == 'JPop') echo 'selected'; ?>>JPop</option>
			<option value="Jazz" <?php if($GenreType == 'Jazz') echo 'selected'; ?>>Jazz</option>
			<option value="Jazz_+_Funk" <?php if($GenreType == 'Jazz_+_Funk') echo 'selected'; ?>>Jazz+Funk</option>
			<option value="Jungle" <?php if($GenreType == 'Jungle') echo 'selected'; ?>>Jungle</option>
			<option value="Latin" <?php if($GenreType == 'Latin') echo 'selected'; ?>>Latin</option>
			<option value="Lo_Fi" <?php if($GenreType == 'Lo_Fi') echo 'selected'; ?>>Lo-Fi</option>
			<option value="Meditative" <?php if($GenreType == 'Meditative') echo 'selected'; ?>>Meditative</option>
			<option value="Merengue" <?php if($GenreType == 'Merengue') echo 'selected'; ?>>Merengue</option>
			<option value="Metal" <?php if($GenreType == 'Metal') echo 'selected'; ?>>Metal</option>
			<option value="Musical" <?php if($GenreType == 'Musical') echo 'selected'; ?>>Musical</option>
			<option value="National_Folk" <?php if($GenreType == 'National_Folk') echo 'selected'; ?>>National Folk</option>
			<option value="Native_US" <?php if($GenreType == 'Native_US') echo 'selected'; ?>>Native US</option>
			<option value="Negerpunk" <?php if($GenreType == 'Negerpunk') echo 'selected'; ?>>Negerpunk</option>
			<option value="Punk_Rock" <?php if($GenreType == 'Punk_Rock') echo 'selected'; ?>>Punk Rock</option>
			<option value="R&B" <?php if($GenreType == 'R&B') echo 'selected'; ?>>R&B</option>
			<option value="Rap" <?php if($GenreType == 'Rap') echo 'selected'; ?>>Rap</option>
			<option value="Rave" <?php if($GenreType == 'Rave') echo 'selected'; ?>>Rave</option>
			<option value="Reggae" <?php if($GenreType == 'Reggae') echo 'selected'; ?>>Reggae</option>
			<option value="Retro" <?php if($GenreType == 'Retro') echo 'selected'; ?>>Retro</option>
			<option value="Revival" <?php if($GenreType == 'Revival') echo 'selected'; ?>>Revival</option>
			<option value="Rhythmic_Soul" <?php if($GenreType == 'Rhythmic_Soul') echo 'selected'; ?>>Rhythmic Soul</option>
			<option value="Rock" <?php if($GenreType == 'Rock') echo 'selected'; ?>>Rock</option>
			<option value="Rock_&_Roll" <?php if($GenreType == 'Rock_&_Roll') echo 'selected'; ?>>Rock & Roll</option>
			<option value="Salsa" <?php if($GenreType == 'Salsa') echo 'selected'; ?>>Salsa</option>
			<option value="Samba" <?php if($GenreType == 'Samba') echo 'selected'; ?>>Samba</option>
			<option value="Satire" <?php if($GenreType == 'Satire') echo 'selected'; ?>>Satire</option>
			<option value="Showtunes" <?php if($GenreType == 'Showtunes') echo 'selected'; ?>>Showtunes</option>
			<option value="Ska" <?php if($GenreType == 'Ska') echo 'selected'; ?>>Ska</option>
			<option value="Slow_Jam" <?php if($GenreType == 'Slow_Jam') echo 'selected'; ?>>Slow Jam</option>
			<option value="Slow_Rock" <?php if($GenreType == 'Slow_Rock') echo 'selected'; ?>>Slow Rock</option>
			<option value="Sonata" <?php if($GenreType == 'Sonata') echo 'selected'; ?>>Sonata</option>
			<option value="Soul" <?php if($GenreType == 'Soul') echo 'selected'; ?>>Soul</option>
			<option value="Sound_Clip" <?php if($GenreType == 'Sound_Clip') echo 'selected'; ?>>Sound Clip</option>
			<option value="Soundtrack" <?php if($GenreType == 'Soundtrack') echo 'selected'; ?>>Soundtrack</option>
			<option value="Southern_Rock" <?php if($GenreType == 'Southern_Rock') echo 'selected'; ?>>Southern Rock</option>
			<option value="Space" <?php if($GenreType == 'Space') echo 'selected'; ?>>Space</option>
			<option value="Speech" <?php if($GenreType == 'Speech') echo 'selected'; ?>>Speech</option>
			<option value="Swing" <?php if($GenreType == 'Swing') echo 'selected'; ?>>Swing</option>
			<option value="Symphonic_Rock" <?php if($GenreType == 'Symphonic_Rock') echo 'selected'; ?>>Symphonic Rock</option>
			<option value="Symphony" <?php if($GenreType == 'Symphony') echo 'selected'; ?>>Symphony</option>
			<option value="Synthpop" <?php if($GenreType == 'Synthpop') echo 'selected'; ?>>Synthpop</option>
			<option value="Tango" <?php if($GenreType == 'Tango') echo 'selected'; ?>>Tango</option>
			<option value="Techno" <?php if($GenreType == 'Techno') echo 'selected'; ?>>Techno</option>
			<option value="Techno_Industrial" <?php if($GenreType == 'Techno_Industrial') echo 'selected'; ?>>Techno-Industrial</option>
			<option value="Terror" <?php if($GenreType == 'Terror') echo 'selected'; ?>>Terror</option>
			<option value="Thrash_Metal" <?php if($GenreType == 'Thrash_Metal') echo 'selected'; ?>>Thrash Metal</option>
			<option value="Top_40" <?php if($GenreType == 'Top_40') echo 'selected'; ?>>Top 40</option>
			<option value="Trailer" <?php if($GenreType == 'Trailer') echo 'selected'; ?>>Trailer</option>
			<option value="Trance" <?php if($GenreType == 'Trance') echo 'selected'; ?>>Trance</option>
			<option value="Tribal" <?php if($GenreType == 'Tribal') echo 'selected'; ?>>Tribal</option>
			<option value="Trip_Hop" <?php if($GenreType == 'Trip_Hop') echo 'selected'; ?>>Trip-Hop</option>
			<option value="Vocal" <?php if($GenreType == 'Vocal') echo 'selected'; ?>>Vocal</option>
		</select>
	</td>
	<td>
		<!-- count_played -->
		<select id="sort-item3" name="CountPlayed" onchange="document.input.submit()">
			<option value="1" <?php if($count_played == 1) echo 'selected'; ?>>Count Played = 0</option>
			<option value="2" <?php if($count_played == 2) echo 'selected'; ?>>Count Played > 0</option>
		</select>
	</td>
	<td>
		<!-- SongType -->
		<select id="sort-item" name="SongType" onchange="document.input.submit()">
			<option value="0" <?php if($SongType == '0') echo 'selected'; ?>>Music</option>
			<option value="1" <?php if($SongType == '1') echo 'selected'; ?>>Jingles</option>
			<option value="2" <?php if($SongType == '2') echo 'selected'; ?>>Sweepers</option>
			<option value="3" <?php if($SongType == '3') echo 'selected'; ?>>Voice Over</option>
			<option value="4" <?php if($SongType == '4') echo 'selected'; ?>>Commercial</option>
			<option value="5" <?php if($SongType == '5') echo 'selected'; ?>>Internet Stream</option>
			<option value="6" <?php if($SongType == '6') echo 'selected'; ?>>Sound Effects</option>
			<option value="7" <?php if($SongType == '7') echo 'selected'; ?>>VDF</option>
			<option value="8" <?php if($SongType == '8') echo 'selected'; ?>>Podcast</option>
			<option value="10" <?php if($SongType == '10') echo 'selected'; ?>>News</option>
			<option value="12" <?php if($SongType == '12') echo 'selected'; ?>>File by Date</option>
			<option value="13" <?php if($SongType == '13') echo 'selected'; ?>>NFF</option>
			<option value="14" <?php if($SongType == '14') echo 'selected'; ?>>Teaser</option>
		</select>
	</td>	
</tr>
<tr>
<td>
	&nbsp;
</td>
<td>
	&nbsp;
</td>
<td>
	&nbsp;
</td>
<td>
	&nbsp;
</td>
<td>
	&nbsp;
</td>

</tr>
</table>	
	</form>
	</div>
	<div style="height: 1500 px;"></div>
	<p></p><br><p></p><br><p></p><br>&nbsp;
<!-- END SEARCH BOX -->	
	
	<script>
	// Script by Fix
	function submitForm() {
	  var input = document.getElementById("campo");
	  localStorage.setItem("userInput", input.value); // Save user input into localStorage
	  document.getElementById("formica").submit(); // Submit form
	}

	window.onload = function() {
	  var input = document.getElementById("campo");
	  input.value = localStorage.getItem("userInput") || ""; // Recover user input to localStorage

	  input.addEventListener("input", function() {
		localStorage.setItem("userInput", input.value); // Update user input into localStorage every time which insert a character
	  });

	  var len = input.value.length;
	  input.focus();
	  input.setSelectionRange(len, len);
	};
	// Script by Fix
	</script>
	
<?php

	$_SESSION['stringSearch'] = $_GET['searchterm'];
	
	//Initial page num setup
	
	/* 160000 entry test OK */
	// $total_pages = 1600000; // Set total amount for page
	/* 160000 entry test OK */
	
	if ($page == 0){$page = 1;}
	$prev = $page - 1; 
	$next = $page + 1;
	$lastpage = ceil($total_pages/$limit);
	$LastPagem1 = $lastpage - 1;
	
	$paginate = '';
	
	if($lastpage > 1) {	
		$paginate .= "<div class='paginate'>";		
		
		// Previous page
		if ($page > 1){
			$paginate.= "<a href='$targetpage?page=$prev$srchpath'>" . NAV_PREV . "</a>";
		}else{
			$paginate.= "<span class='disabled'>" . NAV_PREV . "</span>";
		}
			
		// Pages
		if ($lastpage < 7 + ($stages * 2)) {	
			for ($counter = 1; $counter <= $lastpage; $counter++) {
				if ($counter == $page){
					$paginate.= "<span class='current'>$counter</span>";
				}else{
					$paginate.= "<a href='$targetpage?page=$counter$srchpath'>$counter</a>";
				}					
			}
		} else if($lastpage > 5 + ($stages * 2))	{
		
		// Beginning only hide later pages
			if($page < 1 + ($stages * 2)) {
				for ($counter = 1; $counter < 4 + ($stages * 2); $counter++) {
					if ($counter == $page){
						$paginate.= "<span class='current'>$counter</span>";
					}else{
						$paginate.= "<a href='$targetpage?page=$counter$srchpath'>$counter</a>";
					}
				}
			
				$paginate.= "...";
				$paginate.= "<a href='$targetpage?page=$LastPagem1$srchpath'>$LastPagem1</a>";
				$paginate.= "<a href='$targetpage?page=$lastpage$srchpath'>$lastpage</a>";
				
			} else if($lastpage - ($stages * 2) > $page && $page > ($stages * 2)){
			
				$paginate.= "<a href='$targetpage?page=1$srchpath'>1</a>";
				$paginate.= "<a href='$targetpage?page=2$srchpath'>2</a>";
				$paginate.= "...";
				
				for ($counter = $page - $stages; $counter <= $page + $stages; $counter++){
					if ($counter == $page){
						$paginate.= "<span class='current'>$counter</span>";
					}else{
						$paginate.= "<a href='$targetpage?page=$counter$srchpath'>$counter</a>";
					}
				}
				
				$paginate.= "...";
				$paginate.= "<a href='$targetpage?page=$LastPagem1$srchpath'>$LastPagem1</a>";
				$paginate.= "<a href='$targetpage?page=$lastpage$srchpath'>$lastpage</a>";

			} else {
			
				$paginate.= "<a href='$targetpage?page=1$srchpath'>1</a>";
				$paginate.= "<a href='$targetpage?page=2$srchpath'>2</a>";
				$paginate.= "...";
				
				for ($counter = $lastpage - (2 + ($stages * 2)); $counter <= $lastpage; $counter++) {
					if ($counter == $page){
						$paginate.= "<span class='current'>$counter</span>";
					}else{
						$paginate.= "<a href='$targetpage?page=$counter$srchpath'>$counter</a>";
					}
				}
			}
		}
		// Next page
		if ($page < $counter - 1){ 
			$paginate.= "<a href='$targetpage?page=$next$srchpath'>" . NAV_NEXT . "</a>";
		}else{
			$paginate.= "<span class='disabled'>" . NAV_NEXT . "</span>";
		}	
		$paginate.= "</div>";	
	}

	if($total_pages > 0){
			//Add the pagination
			echo "<div align='center'>$paginate</div><br>";

			//Results table
			echo '<table width=\"100%\">';
			echo " <tr>" . "\n";
			echo "   <td width=\"5%\">" . COL_ALBUM_ART . "</td>\n";
			echo "   <td width=\"23%\">" . COL_ARTIST . "</td>\n";
			echo "   <td width=\"23%\">" . COL_TITLE . "</td>\n";
			if($GenreType != "any_genre") {echo "   <td width=\"12%\">" . COL_GENRE . "</td>\n";}
			echo "   <td width=\"12%\">" . COL_INTRO . "</td>\n";
			echo "   <td width=\"12%\">" . COL_DURATION . "</td>\n";
			echo "   <td width=\"12%\">" . COL_YEAR . "</td>\n";
			echo "   <td width=\"20%\">" . COL_ADD_SONG . "</td>\n";
		echo "   </tr>" . "\n";
		$cnt = 1+($limit*$page)-$limit; //Results counter
		
		//Add results to the table   >>> $result
		while($row = mysqli_fetch_assoc($result)) {
			
			echo "<tr>" . "\n";
			
			if(($row['image']) == true) {
				echo "  <td><img src=\"./Album-Art/" . rawurlencode($row['image']) . "\" alt=\"" . ALT_ALBUM_ART . "\" / width=\"100\" height=\"100\" style=\"border-radius: 15px;\" onmouseover=\"this.width=125;this.height=125;\" onmouseout=\"this.width=100;this.height=100;\"></td>";
			}else{
				echo "  <td><img src=\"./Album-Art/no_cover_image.jpg\" alt=\"" . ALT_ALBUM_ART . "\" / width=\"100\" height=\"100\" style=\"border-radius: 15px;\" onmouseover=\"this.width=125;this.height=125;\" onmouseout=\"this.width=100;this.height=100;\"></td>";
			}
									
			echo "  <td>" . $row['artist'] . "</td>";
			echo "  <td>" . $row['title'] . "</td>";
			if($GenreType != "any_genre") {echo "  <td>" . $row['genre'] . "</td>";} /* */
			echo "  <td>" . htmlspecialchars(gmdate("H:i:s", round($row['intro']))) . "</td>";
			echo "  <td>" . htmlspecialchars(gmdate("H:i:s", round($row['duration']))) . "</td>";
			echo "  <td>" . $row['year'] . "</td>";
			
			if(track_can_play($row['date_played'], $row['artist_played']) == true) {			
				/* This track isn't been played */
				echo "  <td>
					
					<a href=\"addSongTop.php?SongID=" . $row['id'] . "\" title=" . ALT_ADD_TOP . "\" onclick=\"addSongTop();\">
					<button title=\"Add the track to the top\"><span> Add Top </span></button>
						</a>
						
										
					<a href=\"addSongBottom.php?SongID=" . $row['id'] . "\" title=" . ALT_ADD_BOTTOM . "\" onclick=\"addSongBottom();\">
					<button title=\"Add the track at the bottom\"><span>Add Bottom</span></button></a>
						
						</td>";
				
			}
			else{
				/* This track is been played */
				
				echo "  <td class=\"entry_no\" align=\"center\">
						<a href=\"addSongTop.php?SongID=" . $row['id'] . "\" title=\"" . ALT_ADD_TOP . "\" onclick=\"addSongTop();\">
							<button title=\"Add the track to the top\"><span> &nbsp; Add Top &nbsp; ".($row['artist_played'])." </span></button></a>\n";
				
				echo "		<a href=\"addSongBottom.php?SongID=" . $row['id'] . "\" title=\"" . ALT_ADD_BOTTOM . "\" onclick=\"addSongBottom();\">
							<button title=\"Add the track at the bottom\"><span>Add Bottom ".($row['artist_played'])." </span></button></a>
							
						</td>\n";
				
							
			}                                                                                                               
				echo " </tr>" . "\n";
			$cnt++;
		}
	@mysqli_free_result($con, $result);
	
?>
<!-- Total Items top -->
<div class="container">
    <div class="bottom-div1">
		<a href="https://www.paypal.com/donate/?hosted_button_id=N5DMVFQZYPRNE" target="_blank"><img src="./images/donatePayPal.png" style="border-radius: 5px;" height="40" width="150"alt="PayPalDonate"></a>    
    </div>
    <div class="bottom-div2">
        <?php if($cnt-1 < 100) {echo $cnt-1;} else {echo $cnt-1 ." of ". $total_pages;};?> items found.
    </div>
	<div class="bottom-div3">
        <a href="https://www.radiodj.ro/community/index.php/topic,17558.0.html" target="_blank"><img src="./images/assistance.png" style="border-radius: 5px;" height="40" width="150"alt="Assistance\"></a>
    </div>
</div>
<p></p><p></p><br>
<!-- Total Items top -->

</table>
<br />

<!-- After 100 items paginate -->
<!-- Total Items bottom -->
<div class="container">
	<div class="bottom-div1">
		<a href="https://www.radiodj.ro/community/index.php/topic,17558.0.html" target="_blank"><img src="./images/assistance.png" style="border-radius: 5px;" height="40" width="150"alt="Assistance\"></a>
    </div>
    <div class="bottom-div2">
        <?php if($cnt-1 < 100) {echo $cnt-1;} else {echo $cnt-1 ." of ". $total_pages;};?> items found.
    </div>
	<div class="bottom-div3">
		<a href="https://www.paypal.com/donate/?hosted_button_id=N5DMVFQZYPRNE" target="_blank"><img src="./images/donatePayPal.png" style="border-radius: 5px;" height="40" width="150"alt="PayPalDonate"></a>
    </div>
</div>		
<p></p>
<center><a href="#">Go top</a></center>
<p></p><br>
<!-- Total Items bottom -->
<?php
	//Add the bottom pagination
		echo '<div align="center">' . $paginate . '</div>';
	}else{
		echo "<div class=\"errordiv\">" . MSG_NORESULTS . "</div><p>";
		echo "<center><a href=\"search.php\">Back to Search Page</a></center>";
	}
}
	require_once('footer.php');
?>
</body>
</html>