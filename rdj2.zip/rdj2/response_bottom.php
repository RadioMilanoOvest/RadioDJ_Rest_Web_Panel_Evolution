<!-- doctype html  --> 
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="refresh" content="4; URL='search.php'">
	<title>Response page - Song added at the top of the playlist!</title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body link="#FFFFFF" alink="#FFFFFF" vlink="#FFFFFF">
<p><h2><center><font color="FFFFFF">
	
<?php
		session_start();
		require_once('serv_inc.php');
		$id = $_SESSION['SongID'];
		
		$query1 = "SELECT `image`, `id`, `artist`, `title`, SUBSTRING(CUE_TIMES, 4 + INSTR( CUE_TIMES,'INT'), 8) as `intro`, `duration`, `year` , `date_played`, `artist_played` FROM `songs` WHERE `id` = $id";
		////////////////////////////////////
		mysqli_set_charset($con, "utf8");
		////////////////////////////////////
		$result = mysqli_query($con, $query1);
		//////////////////////
		if($result === FALSE) { 
        die(mysqli_error($con)); // better error handling
		}
		//////////////////////
		
		while($row = mysqli_fetch_assoc($result)) {
			//Results table
			echo '<table width=\"100%\">';
			echo " <tr>" . "\n";
			echo "   <td>".COL_ALBUM_ART."</td>\n";
			echo "   <td>" . COL_ID . "</td>\n";
			echo "   <td>" . COL_ARTIST . "</td>\n";
			echo "   <td width=\"15%\">" . COL_TITLE . "</td>\n";
			echo "   <td width=\"15%\">" . COL_INTRO . "</td>\n";
			echo "   <td width=\"15%\">" . COL_DURATION . "</td>\n";
			echo "   <td width=\"15%\">" . COL_YEAR . "</td>\n";
			echo " </tr>" . "\n";
			
			echo " <tr>" . "\n";
			//////////////////////////////////////////////
			if(($row['image']) == true) {
				echo "  <td><img src=\"./Album-Art/" . rawurlencode($row['image']) . "\" alt=\"" . ALT_ALBUM_ART . "\" / width=\"150\" height=\"150\" style=\"border-radius: 15px;\"></td>\n";
			}else{
				echo "  <td><img src=\"./Album-Art/no_cover_image.jpg\" alt=\"" . ALT_ALBUM_ART . "\" / width=\"150\" height=\"150\" style=\"border-radius: 15px;\"></td>\n";
			}
			//////////////////////////////////////////////
			echo "  <td>". $row['id'] ."</td>\n";
			echo "  <td>" . $row['artist'] . "</td>\n";
			echo "  <td>" . $row['title'] . "</td>\n";
			echo "  <td>" . htmlspecialchars(gmdate("H:i:s", round($row['intro']))) . "</td>\n";
			echo "  <td>" . htmlspecialchars(gmdate("H:i:s", round($row['duration']))) . "</td>\n";
			echo "  <td>" . $row['year'] . "</td>\n";
			echo " </tr>" . "\n";
			echo " </table>" . "\n";

		}
		@mysqli_free_result($con, $result);
?>
<br><p><br><p><br><p>
<font><h2><center><i>Song added at the bottom of the playlist!</i></center></h2></font></p>
<p><h3><center><font color="FFFFFF"><a href="search.php">Back to Search Page</a></center></h3></font></p> 
</body>
</html>
 

