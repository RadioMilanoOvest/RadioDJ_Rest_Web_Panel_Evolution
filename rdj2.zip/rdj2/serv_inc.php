 <?php
/*
Installation:
- Edit the server details below;
- If using this script on a webserver and the MySQL database on another server, make sure that the
MySQL user has access from your webserver and the firewall ports are open both on the webserver and on your MySQL server computer;

For detailed info about creating MySQL users, please read this:
http://dev.mysql.com/doc/refman/5.5/en/adding-users.html

  
  
        >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> USE IT AT YOUR OWN RISK! >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  



/* ============================================================================= */
// EDIT BELOW
/* ============================================================================= */

$stationName = "FIX & Radio Milano Ovest";	 //Your Station name
$copyYear = 2024;                        	// your station starting year
$mysqli_server	= "127.0.0.1";			 	// MySQL Server's IP (and port if not default). Ex: (191.268.1.2 or 191.268.1.2:345).
$mysqli_database	= "Radiodj2006";	 	// MySQL database name
$mysqli_user		= "Radiodj1820";	 	// MySQL database username. Usually root.
$mysqli_pass		= "Radiodj2023$";	 	// MySQL database password.
$mysqli_port		= "3306";            	// MySQL port number.
$track_repeat	= 60;					 	// Display the track if it was played in the last X minutes.
$artist_repeat	= 60;					 	// Display the track if the artist was played in the last X minutes.
$def_timezone	= 'Europe/Rome';		 	// Set your time-zone.


error_reporting(E_ALL); 
error_reporting(E_WARNING);
ini_set('error_log', 'php_errors.log');
//Please enter REST server plugin connection details
$ipAddress = "127.0.0.1";
$restPort = "5555";
$restPassword = "Radiodj2023$";


/*############ show on the pages ###########*/
$limit = 100;     	//How many upcoming tracks to display?

/* ============ Pages translation you can make =============== */
//Page names
define("COL_Delete_History_Songs","Delete History Songs");
define("COL_DURATION", "Duration");
define("COL_ID", "ID");
define("COL_ARTIST", "Artist");
define("COL_DATE_PLAYED", "Date Played");
define("COL_POSITION", "Position");
define("COL_HISTORY", "History of songs");
define("ERROR_UNKNOWN", "Unknown error occurred! Please try again...");
define("MSG_NORESULTS", " No results to display...");
define("SEARCH_TXT", " TYPE artist, title or year: ");
define("RESET_TXT", "X");
define("SEARCH_BUTTON", "Search");
define("COL_YEAR", "Year");
define("COL_GENRE", "Genre");
define("COL_ALBUM_ART", "Cover");
define("COL_TITLE", "Title");
define("COL_INTRO", "Intro");
define("COL_ADD_SONG", "Top/Bottom");
define("SERVER_OFFLINE", "For the moment, our server is off-line.<br />Please come back later... ");
define("RIGHT", "All Rights Reserved.");
define("NAV_PREV", "Previous");
define("NAV_NEXT", "Next");

/* ========== The functions do not edit ========== */

function track_can_play($tr_played, $art_played){
	global $track_repeat, $artist_repeat;

	$date1 = strtotime($tr_played);
	$date2 = time(); 
	$subTime = $date1 - $date2;
	$tr_min = round(abs($subTime/60));

	$date1 = strtotime($art_played);
	$date2 = time();
	$subTime = $date1 - $date2;
	$ar_min = round(abs($subTime/60));
	
	if($tr_min > $track_repeat && $ar_min > $artist_repeat){
		return true;
	}else{
		return false;
	}
}

// Database connection with mysqli.
$con = @mysqli_connect($mysqli_server, $mysqli_user, $mysqli_pass, $mysqli_database, $mysqli_port);
	if (!$con) {
			echo '<p>'.SERVER_OFFLINE.'</p>';
		require_once('footer.php');
		die();
	}
?> 