<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard 3.0</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body link="red" alink="red" vlink="red">
<table border="1" width="100%">
<?php

require_once('serv_inc.php');
     
echo " <tr>" . "\n";
echo "   <td class=\"tablecell2\" width=\"10%\">".COL_POSITION."</td>\n";
echo "   <td class=\"tablecell2\" width=\"17%\">".COL_DATE_PLAYED."</td>\n";
echo "   <td class=\"tablecell2\" width=\"32%\">".COL_ARTIST."</td>\n";
echo "   <td class=\"tablecell2\" width=\"32%\">".COL_TITLE."</td>\n";
echo "   <td class=\"tablecell2\" width=\"7%\">".COL_DURATION."</td>\n";
echo " </tr>" . "\n";

?>
</table>
</body>
</html>
