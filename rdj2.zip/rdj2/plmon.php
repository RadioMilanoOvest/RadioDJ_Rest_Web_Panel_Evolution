<html>
<head>
<script src="jquery/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
</head>
<body>

<?php
session_start();
require('config.php');
require('includes/functions.php');

// Bust cache. Mainly for IE
header('Cache-Control: no-cache, no-store');
header('Expires: '.date(DATE_RFC822));

$time = date('H:i:s', time());

$xml = null;

try {
	$xml = simplexml_load_file("http://".$ipAddress.":".$restPort."/p?auth=".$restPassword);
} catch(Exception $e) {
	http_response_code(500); // Internal Server Error 1°
	echo $e->getMessage();
}

if($xml) {
	if(isset($_GET['json'])) {
		header('Content-Type: text/json');
		echo json_encode($xml);
	} else {
		$rowID = 0;
		
		foreach ( $xml->SongData as $playlistItem ) {
			// Skip already playing track
			if($rowID == 0) {			
?>				
				<input type="hidden" id="currentTrack" data-id="<?php echo $playlistItem->ID; ?>" data-track="<?php echo htmlspecialchars(str_replace('{}', '""', json_encode($playlistItem, false)));?>">
<?php
			}			
			else 
			{
?>			<table width="100%">
			<!-- ID, TrackType (item color), ID e rowID -->		
			<tr class="item tracktype-<?php echo strtolower($playlistItem->TrackType); ?>" data-id="<?php echo $playlistItem->ID; ?>"data-index="<?php echo($rowID-1); ?>">
					
			<!-- ITEM -->
				<td class="controls" rowspan="1">
					<button class="playbutton" title="Play this item">
					<font size="4"><b>
					<?php
						$rowID_max = $_SESSION['item_count'];
						echo($rowID)."/".($rowID_max);				
					?>
					</b></font>
					</button>
				 </td>
					
			<!-- AlbumArt -->
				<td class="controls" rowspan="1">
					<img src="./Album-Art/<?php if($playlistItem->AlbumArt != "no_cover_image.jpg" || $playlistItem->AlbumArt != "") echo rawurlencode($playlistItem->AlbumArt); else echo "no_cover_image.jpg";?>" width="80" height="80" style="border-radius: 15px;">
				</td>
			<!-- Artist, Title, Year, Duration, Summary_Time, Intro and Outro -->
				<td rowspan="1" width="70%">
					<!-- Artist --><!-- Title  -->
					<h6 class="plArtist"><b>
					<a href="https://en.wikipedia.org/wiki/<?php echo htmlspecialchars($playlistItem->Artist);?>" target="_blank" style="color:#FFFFFF">
					 Artist (<?php echo truncate(htmlspecialchars($playlistItem->Artist), 50);?>)<br>
					 Title (<?php echo truncate(htmlspecialchars($playlistItem->Title), 50);?>)<br>
					</a>
					</b>
					</h6>
					
					<!-- Durate  -->
					<h1 class="plDuration"><b>
					<!-- -->
					 Duration <?php echo htmlspecialchars(gmdate("H:i:s", round($playlistItem->Duration)));?>
					 - Intro <?php echo htmlspecialchars(gmdate("H:i:s", round($playlistItem->cueIntro))); ?>
					 - Outro <?php echo htmlspecialchars(gmdate("H:i:s", round($playlistItem->cueOutro)));?>
					<!-- -->
					</b>
					</h1>								
					<h6 class="plDuration"><b>
					<?php
					/* Summary Time by Fix */
					$Duration[$rowID] = gmdate("H:i:s", round($playlistItem->Duration));
					$Remaining = gmdate("H:i:s", round($_SESSION['Remaining']));
					$Endplaylist = summary_Time($time, $Duration, $Remaining, $rowID);
					echo "<b> End of the track </b> $Endplaylist"." - Year ". htmlspecialchars($playlistItem->Year)." - "."<b>   Song ID:</b> " . $playlistItem->ID;
					?>
					</b>
					</h6>
					
				</td>
				<!-- Item remove  -->
				<td class="controls" rowspan="1" width="1%">
					<button class="clearbutton" title="Remove this item">&times;</button>
				</td>
			</tr>
			</table>
</body>
</html>
<?php			
			}
			$rowID++;
		}	
	}
}
?>
<?php
		$rowID_max = $rowID-1;
		$_SESSION['item_count'] = $rowID_max;
?>