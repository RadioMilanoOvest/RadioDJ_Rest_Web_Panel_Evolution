<html>
<link rel="icon" type="image/png" sizes="48x48" href="./images/logo.png">
<body bgcolor="#555">
<script>
function resetForm() {
    document.getElementById('form').reset();
}
</script>
<center>
<p></p><br><p></p><br><p></p><br>
<p></p><br><p></p><br><p></p><br>
<form id="form" method="post" action="">
<table border="0">
	<tr>
		<td align="center"><font size="10" color="white">Rest Web Panel Evolution</font>&nbsp; <font size="5" color="white">by <i>Fix</i></font></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td align="center">
		<?php 
		session_start();
		$username = 'rotartsinimda';
		$password = 'Ufolino2024$'; 

		if (isset($_POST['username']) && isset($_POST['password'])) {
			if ($_POST['username'] == $username && $_POST['password'] == $password) {
				$_SESSION['guaranteed_access'] = true;
				header('Location: index1.php');
				exit;
			} else {
				echo '<font size="4" color="red">Accesso negato, nome utente o password errati.</font>';
			}
		}
		?>
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td align="center"><font size="3" color="white"><b>Username:</b></font> <input type="text" name="username"><br></td>
	</tr>
	<tr>
		<td align="center"><font size="3" color="white"><b>Password:</b></font> &nbsp;<input type="password" name="password"><br></td>
	</tr>
	<tr>
		<td align="center">&nbsp;<br></td>
	</tr>
	<tr>
		<td align="center"><input type="submit" value="Login"><input type="button" value="Cancel" onclick="resetForm()"></td>
	</tr>
<table>
</center>
</form>

</body>
</html>