<?php
//error_reporting(E_ALL);
error_reporting(E_WARNING);
ini_set('error_log', 'php_errors.log');
//Please enter REST server plugin connection details
$ipAddress = "127.0.0.1";
$restPort = "5555";
$restPassword = "Radiodj2023$";
?>
