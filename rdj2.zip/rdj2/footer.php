<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Search Page</title>
<!-- <style type="text/css" media="all">@import "style.css";</style> -->
<!-- <style type="text/css"> @import ("style.css");</style> -->
<!-- <link rel="stylesheet" type="text/css" href="style.css" media="screen" /> -->
</head>
<body>
<br />
<div class="footer">&copy;
<?php 
global $stationName;

$curYear = date('Y');
echo $copyYear . (($copyYear != $curYear) ? '-' . $curYear : '');
echo "&nbsp;" . $stationName . ",&nbsp;".RIGHT." &nbsp;&nbsp;</div>";
?>
</div>
</body>
</html>