<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard 3.0</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
<table>

<?php
     
echo " <tr>" . "\n";
echo "   <td class=\"tablecell\" width=\"10%\">Position</td>\n";
echo "   <td class=\"tablecell\" width=\"28%\">Artist</td>\n";
echo "   <td class=\"tablecell\" width=\"26%\">Title</td>\n";
echo "   <td class=\"tablecell\" width=\"26%\">Date & Time</td>\n";
echo "   <td class=\"tablecell\" width=\"7%\">Duration/Hit</td>\n";
echo " </tr>" . "\n";

?>
</table>
</body>
</html>
