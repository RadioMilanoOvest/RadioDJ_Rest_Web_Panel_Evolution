	/* APP 1 */
	function addSongTop() {
		$.get("addSongTop.php", function(response){	
		});
	}

	function addSongBottom() {
		$.get("addSongBottom.php", function(response){	
		});
	}
	/* APP 2 */
    $(window).scroll(function () {
        clearTimeout($.data(this, 'scrollTimer'));
        $("#searching").css("display", "none");
        $.data(this, 'scrollTimer', setTimeout(function () {
            $("#searching").css("display", "block");
        }, 250));
    });