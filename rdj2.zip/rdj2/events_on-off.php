<?php
/* Script by Fix */
require('config.php');
require('includes/functions.php');

header('Content-Type: text/json');
// Bust cache. Mainly for IE
header('Cache-Control: no-cache, no-store');
header('Expires: '.date(DATE_RFC822));

$status = array(
	'eventsOn' => true,
	'changed' => false
);

if(isset($_COOKIE["EventsStatusOn"])) {
	$status['eventsOn'] = false;
	setcookie("EventsStatusOn", "1", time()-3600);
}

if(isset($_COOKIE["EventsStatusOff"])) {
	$status['eventsOn'] = true;
	setcookie("EventsStatusOff", "1", time()-3600);
}

try {
	switch ($status['eventsOn']) {
		case true:
					$status['changed'] = file_get_contents("http://".$ipAddress.":".$restPort."/opt?auth=".$restPassword."&command=EnableEvents&arg=0");
					if(!isset($_COOKIE["EventsStatusOn"])) {
						setcookie("EventsStatusOn", "1", time()+3600);
						$status['eventsOn'] = false;
					}	
		break;
		case false:
					$status['changed'] = file_get_contents("http://".$ipAddress.":".$restPort."/opt?auth=".$restPassword."&command=EnableEvents&arg=1");
					if(!isset($_COOKIE["EventsStatusOff"])) {
						setcookie("EventsStatusOff", "1", time()+3600);
						$status['eventsOn'] = true;
					}					
		break;
		default:
					echo "Problem about your choice. Click another item!"; 
	}

} catch (Exception $e) {
	http_response_code(500);
	$status['error'] = $e->getMessage();
}
exit(json_encode($status));
?>