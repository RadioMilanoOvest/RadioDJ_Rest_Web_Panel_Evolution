<html>
<head>
	<!-- For use with RadioDJ 1.8.2 or superior with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" sizes="48x48" href="./images/logo.png">
	<title>Rest Web Panel Evolution</title>
</head>
<body>
<?php
	echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\"><p><br>";
	echo "<body alink=white vlink=white link=white>";
	echo " <table border=\"0\">";
	echo " <tr>" . "\n";
	echo "  <td class=\"tablecell\"><font size=\"5\" color=\"white\">&nbsp&nbsp About Rest Web Panel Evolution, Donate, Powered by and Assistance</font>
			</td>\n";
	echo " </tr>" . "\n";
	
	echo " <tr>";
	echo "  <td class=\"tablecell\"><font color=\"white\">&nbsp&nbsp Web Application based on the analysis / study of the Rest Web-Panel 0.2b
			and RadioDJ Demo script 2.2.3 interfaces, Fabio Fix Cassarà has developed the advanced version of the Rest Web-Panel Evolution.
			</font>
			</td>\n";
	echo " </tr>";
	
	echo " <tr>";
	echo " <td>&nbsp;";
	echo " </td>";
	echo " </tr>";
	
	echo " <tr>";
	echo " <td>";
	echo " </td>";
	echo " </tr>";
	
	echo " <tr>";
	echo " <td>&nbsp;";
	echo " </td>";
	echo " </tr>";
		
	echo " <tr>" . "\n";
	echo "  <td class=\"tablecell\"><center><font color=\"white\">Powered by FIX & Radio Milano Ovest</a><font></center></td>\n";
    echo " </tr>" . "\n";
	
	echo " <tr>" . "\n";
	echo "	<td class=\"tablecell\">&nbsp</td>\n";
	echo " </tr>" . "\n";
	
	echo " <tr>" . "\n";
	echo "	<td class=\"tablecell\">
			<center> <a href=\"https://www.paypal.com/donate/?hosted_button_id=N5DMVFQZYPRNE\" target=\"_blank\"><img src=\"./images/donatePayPal.png\" style=\"border-radius: 20px;\" height=\"40\" width=\"150\"alt=\"PayPalDonate\"></a> </center></td>\n";
	echo " </tr>" . "\n";
	
	echo " <tr>" . "\n";
	echo "	<td class=\"tablecell\">&nbsp</td>\n";
	echo " </tr>" . "\n";
	
	echo " <tr>" . "\n";
	echo "  <td class=\"tablecell\"><center><font color=\"white\">Assistance: <a href=\"https://www.radiodj.ro/community/index.php/topic,17558.0.html\">Forum RadioDJ</a><font></center></td>\n";
    echo " </tr>" . "\n";
	echo " </table></center>";
?>
</body>
</html>