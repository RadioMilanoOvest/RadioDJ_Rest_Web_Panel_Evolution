<?php
/* Script by Fix */
require('config.php');
require('includes/functions.php');

header('Content-Type: text/json');
// Bust cache. Mainly for IE
header('Cache-Control: no-cache, no-store');
header('Expires: '.date(DATE_RFC822));


$status = array(
	'pause' => true,
	'changed' => false
);

/* Se il cookie ON è settato */
if (isset($_COOKIE["PausePlayerStatusOn"])) {
	/* Assegno false a $status['pause'] */
	$status['pause'] = false;
	/* Distruggo un eventuale cookie PausePlayerStatusOff */
	setcookie("PausePlayerStatusOn", "1", time()-3600);
}

/* Se il cookie OFF è settato */
if(isset($_COOKIE["PausePlayerStatusOff"])) {
	/* Assegno true a $status['pause'] */
	$status['pause'] = true;
	/* Distruggo un eventuale cookie PausePlayerStatusOn */
	setcookie("PausePlayerStatusOff", "1", time()-3600);
}

try {
	switch ($status['pause']) {
		case true:
					$status['changed'] = file_get_contents("http://".$ipAddress.":".$restPort."/opt?auth=".$restPassword."&command=PausePlayer&arg=1");
					setcookie("PausePlayerStatusOn", "1", time()+3600);
		break;
		case false:
					$status['changed'] = file_get_contents("http://".$ipAddress.":".$restPort."/opt?auth=".$restPassword."&command=PausePlayer&arg=0");
					setcookie("PausePlayerStatusOff", "1", time()+3600);
		break;
		default:
					echo "Problem about your choice. Click another item!"; 
	}

} catch (Exception $e) {
	http_response_code(500);
	$status['error'] = $e->getMessage();
}
exit(json_encode($status));
?>