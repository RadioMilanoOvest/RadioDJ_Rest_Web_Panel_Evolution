<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2.0 or superior with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST Web Panel Evolution</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<script src="jquery/jquery.min.js"></script>
	<script type="text/javascript">
		idSetInterval = setInterval(nowPlayingMonitor, 1000);
		function nowPlayingMonitor() {
				$.get("np-json.php", function(data)
				{ 	timeForwarding = data.secondsForwarding;
					timeMixing = Math.floor(timeForwarding);
					if(timeMixing == 1){
						location.href="history_songs_body.php";
						clearInterval(idSetInterval);
					}
				});	
		}
	</script>
</head>
<body>
<?php

require_once('serv_inc.php');
date_default_timezone_set($def_timezone);

?>
<table>
<?php

$query = "SELECT `date_played`, `artist`, `title`, `duration` FROM `history` ORDER BY `date_played` ASC";

mysqli_set_charset($con, "utf8");

$result = mysqli_query($con, $query);
	
if (!$result) {
	echo mysqli_error();
	exit;
}

if (mysqli_num_rows($result) == 0) {
	echo "<p><br><center>".MSG_NORESULTS."</center>";
	exit;
}

$inc = 1;

while($row = mysqli_fetch_assoc($result)) {

	echo " <tr>" . "\n";
	echo "  <td class=\"tablecell\" width=\"10%\">" . $inc . "</td>\n";	
	echo "  <td class=\"tablecell\" width=\"30%\">" . $row['artist'] . "</td>\n";
	echo "  <td class=\"tablecell\" width=\"28%\">" . $row['title'] . "</td>\n";
	echo "  <td class=\"tablecell\" width=\"30%\">" . $row['date_played'] . "</td>\n";
	echo "  <td class=\"tablecell\" width=\"7%\">" . gmdate("H:i:s", round($row['duration'])) . "</td>\n";
	echo " </tr>" . "\n";

	$inc += 1;
}
@mysqli_free_result($con, $result);
mysqli_close($con);

?>
</table>
</body>
</html>