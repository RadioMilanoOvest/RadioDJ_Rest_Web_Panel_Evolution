<!-- doctype html  --> 
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta http-equiv="refresh" content="4; URL='search.php'">
	<title>Response page - Song added at the top of the playlist!</title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body link="#FFFFFF" alink="#FFFFFF" vlink="#FFFFFF">
<p><h2><center><font color="FFFFFF">

<?php
		session_start();
		require_once('serv_inc.php');
		require_once('includes/functions.php');
				
		if(isset($_SESSION['SongID'])){
			$id = $_SESSION['SongID'];
		}
		else
			echo "id non settato\n ";
		
		$query1 = "SELECT `album_art`, `id`, `artist`, `title`, SUBSTRING(CUE_TIMES, 4 + INSTR( CUE_TIMES,'INT'), 3) as `intro`, `duration`, `year` FROM `songs` WHERE `id` = $id";
		
		mysqli_set_charset($con, "utf8");
		
		$result = mysqli_query($con, $query1);		
				
		if (!$result) {
			$error = mysqli_error($con);
			$errorCode = mysqli_errno($con);

			echo "Error query: $error";
			echo "Error code: $errorCode";
		}
		
		while($row = mysqli_fetch_assoc($result)) {
			//Results table
			echo '<table width=\"100%\">';
			echo " <tr>" . "\n";
			echo "   <td>".COL_ALBUM_ART."</td>\n";
			echo "   <td>" . COL_ID . "</td>\n";
			echo "   <td>" . COL_ARTIST . "</td>\n";
			echo "   <td width=\"15%\">" . COL_TITLE . "</td>\n";
			echo "   <td width=\"15%\">" . COL_INTRO . "</td>\n";
			echo "   <td width=\"15%\">" . COL_DURATION . "</td>\n";
			echo "   <td width=\"15%\">" . COL_YEAR . "</td>\n";
			echo " </tr>" . "\n";
			
			echo " <tr>" . "\n";
		
			if(($row['album_art']) == true) {
				echo "  <td><img src=\"./Album-Art/" . rawurlencode($row['album_art']) . "\" alt=\"" . ALT_ALBUM_ART . "\" / width=\"120\" height=\"120\" style=\"border-radius: 15px;\"></td>\n"; 
			}else{
				echo "  <td><img src=\"./Album-Art/no_cover_image.jpg\" alt=\"" . ALT_ALBUM_ART . "\" / width=\"120\" height=\"120\" style=\"border-radius: 15px;\"></td>\n";
			}
			
			echo "  <td>". $row['id'] ."</td>\n";
			echo "  <td>" . $row['artist'] . "</td>\n";
			echo "  <td>" . $row['title'] . "</td>\n";
			echo "  <td>" . htmlspecialchars(gmdate("H:i:s", round($row['intro']))) . "</td>\n";
			echo "  <td>" . htmlspecialchars(gmdate("H:i:s", round($row['duration']))) . "</td>\n";
			echo "  <td>" . $row['year'] . "</td>\n";
			echo " </tr>" . "\n";
			echo " </table>" . "\n";

		}
		@mysqli_free_result($con, $result);
?>
<br><p><br><p><br><p>
<font><h3><center><i>Song added at the top of the playlist!</i></center></h3></font></p>
<p><h4><center><font color="FFFFFF"><a href="search.php">Back to Search Page</a></center></h4></font></p> 
</body>
</html>