///////////////////////////////
//    ####### # #     #
//   #       #   #  #
//  ####    #     # 
// #       #    #   #
//#       #   #      # SCRIPT
//////////////////////////////

(function($){
	$(document).ready(function() {
		$('#play').click(function(){
			playPlaylistTrack(0);
			$(this).blur();
		});

		$('#events-act').click(function(){
			eventsAction();
			$(this).blur();			
		});

		$('#stop').click(function(){
			playerSTOP();
			$(this).blur();
		});
		
		$('#pause').click(function(){
			playerPAUSE();
			$(this).blur();
		});
		
		$('#intro').click(function(){
			playerINTRO();
			$(this).blur();
		});
		
		$('#restart').click(function(){
			playerRESTART();
			$(this).blur();
		});

		$('#events-refresh').click(function(){
			EventsRefresh();
			$(this).blur();			
		});
		
		$('#autodj').click(function(){
			toggleAutoDJ();
			$(this).blur();
		});

		$('#assisted').click(function(){
			toggleAssisted();
			$(this).blur();
		});

		$('#lineinput').click(function(){
			toggleLineInput();
			$(this).blur();
		});

		$('#clear').click(function(){
			clearPlaylist();
			$(this).blur();
		});
		
		$('#playlistRows').on('click', '.playbutton', function(){
			$(this).parents('tr.item').remove();
			var trackRow = $(this).parents('tr.item');
			var index = trackRow.data('index');
			playPlaylistTrack(index);
			trackRow.remove();
		});

		$('#playlistRows').on('click', '.clearbutton', function(){
			var trackRow = $(this).parents('tr.item');
			var index = trackRow.data('index');
			dropPlaylistTrack(index);
			trackRow.remove();
		});

		if(window.console != undefined)
		
		/* Prevent IE from caching AJAX requests */		
		
		$.ajaxSetup({ cache: false });
		/* Error App */
		var xhrFailed = false;
		$(document).ajaxError(function(event, jqxhr, settings, thrownError) {
			// Stop all timers if error occurs
			stop();
			
			var message = thrownError;

			if(jqxhr.status >= 400 || jqxhr.status === 0) {
				message = jqxhr.responseJSON != undefined ? jqxhr.responseJSON.error : (jqxhr.responseText? jqxhr.responseText : jqxhr.status+" - "+thrownError);
			}
			$('.notification').html('<p class="error notice">Si è verificato un errore. Vedi il <a href="#thelog">Log</a>.</p>').slideDown('fast');
			
			$(".log" ).append('<div class="notice error"><b>Errore:</b> '+ message +'</div>');

			if(window.console != undefined)
				console.log(jqxhr, thrownError);
			xhrFailed = true;
		});
		
		/* Error App */
        
		// Check for connection status and init only if connection works
		$.ajax({
			url: "status-check.php",
			method: 'GET',
			success: function(){
				//console.log("status check");
				init();
			}
		});

	});
	
	var montime, nptime, nptime2, nptime3, nptime4, playingTimer, playingTimer2, playingTimer3, playingTimer4, rdjStatusTimeout;
	var isplaying = false;
	var call = false;
	var timeForwarding = 0;
	var triggerNextTrack = false;
	var triggerNowPlaying = true;
	var AlbumArtFile;
	var AlbumArtFile2;
	var AlbumArtFile3;
	
	var timeOutro = 0;
	var timerOutro = 0;
	var timerIntro = 0;
	var timeRemaining = 0;
	var timeDuration = 0;
		
	var trackEndsAt = new Date();
	var trackIntrosAt = new Date();
	var trackForwardsAt = new Date();
	var trackOutrosAt = new Date();
	var trackID = 0;
	var pauseControl = 2;
	var CurrentArtist;
	var	CurrentTitle;
	var NextArtist;
	var NextTitle;
	
	
	function init() {
		rdjStatus();
		nowPlayingMonitor();
		playlistMonitor();
		nextPlayingMonitor();
	}
	
	function stop(){
		clearTimeout(montime); //
		clearTimeout(nptime);
		clearTimeout(nptime2);
		clearTimeout(playingTimer);
		clearTimeout(playingTimer2);
		clearTimeout(playingTimer3);
		clearTimeout(rdjStatusTimeout);
		resetNowPlaying();
	}
	
	function intro(){
		clearTimeout(montime);
		clearTimeout(nptime0);
		clearTimeout(nptime);
		clearTimeout(nptime2);
		clearTimeout(playingTimer);
		clearTimeout(rdjStatusTimeout);
		resetNowPlaying();
	}
	
	function restart(){		
		nowPlayingMonitor();
		resetNowPlaying();
		nextPlayingMonitor();
	}
	
	setInterval(nextPlayingMonitor, 5000);
		
	function nextPlayingMonitor() {
		$.get("nt-json.php", function(data)
		{ 
			CurrentArtist = data.CurrentArtist;
			CurrentTitle = data.CurrentTitle;
			
			NextArtist = data.NextArtist;
			NextTitle = data.NextTitle;
			
			AlbumArtFile2 = data.AlbumArtURI1;
			nextTrackAlbumArt1(AlbumArtFile2);
			
			AlbumArtFile3 = data.AlbumArtURI2;
			nextTrackAlbumArt2(AlbumArtFile3);
	
		});	
	}
	
	function nowPlayingMonitor() {
		$.get("np-json.php", function(data)
		{ 
			$('#nowPlayingArtist').html(data.Artist);
			$('#nowPlayingTitle').html(data.Title);
			$('#nowPlayingYear').html(data.Year);
			$('#nowPlayingAlbum').html(data.Album);
			$('#nowPlayingComposer').html(data.Composer);
			$('#nowPlayingPublisher').html(data.Publisher);
			$('#nowPlayingCopyright').html(data.Copyright);
			$('#nowPlayingTrackCD').html(data.TrackNo);
			
			isplaying = data.isplaying;
			
			timeDuration = Math.round(data.secondsDuration);
			
			if(isplaying){
				timeForwarding = data.secondsForwarding;
				trackForwardsAt = new Date(new Date().valueOf()-(data.secondsForwarding*1000));
				if(data.secondsRemaining > 1) {
					nptime = setTimeout(nowPlayingMonitor, data.secondsRemaining*1000);
				}
				else
				{
					clearTimeout(nptime);
				}
				nptime = setTimeout(Forwarding, 1000);
			}
			else
			{
				clearTimeout(nptime);
			}
			
			if(isplaying){
				timeRemaining = data.secondsRemaining; // in seconds
				trackEndsAt = new Date(new Date().valueOf()+(data.secondsRemaining*1000)); // in mseconds
				nptime2 = setTimeout(Remaining, 1000);
			}
			else{
				clearTimeout(nptime2);
			}
						
			if(isplaying){		
				trackIntrosAt = new Date(new Date().valueOf()+(Math.round(data.dynamicIntro*1000))); // mseconds
				timerIntro = Math.round((trackIntrosAt - new Date())/1000);				
				
				if(timerIntro > 0)
				{
					nptime3 = setTimeout(function(){ IntroRemaining(); }, 1000);
				}
				else
				{
					clearTimeout(nptime3);
				}
			}
						
			if(isplaying){
				if(isNaN(data.dynamicOutro)) {
					/*  */
				} 
				else
				{
					timeOutro = Math.round(data.dynamicOutro);// secondi
					trackOutrosAt = new Date(new Date().valueOf()+(timeOutro*1000));
					timerOutro = Math.round((trackOutrosAt - new Date())/1000);
					
					if(timerOutro > 1 || call == false)
					{
						nptime4 = setTimeout(function(){ OutroRemaining(/* timerOutro */); }, 1000);
						call = true;
					}
					if(timerOutro < 1)
					{ 
						clearTimeout(nptime4);
						call = false;
					}
				}
			}
			
			AlbumArtFile = data.AlbumArtImagePath;
			nowPlayingAlbumArt0(AlbumArtFile);
			
			setTimeout(function(){ playlistMonitor(); setTimerDurationNP(timeDuration); }, 1000);
			
		});	
	}
			
	function playlistMonitor() {
		clearTimeout(montime);
		$.get("plmon.php", function(response){
			$('#playlistRows').html(response);
			montime = setTimeout(playlistMonitor, 5000);

			if(trackID != $('#currentTrack').data('id')) {
				nowPlayingMonitor();
				nextPlayingMonitor();
			}
			
			trackID = $('#currentTrack').data('id');
		});
	}
	///////////////////////////////////////////////////////////////////////////////////////////////
	function toggleAutoDJ() {
		$.get("autodj-toggle.php", function(data) {
			if(data.autodj == true) {
				$('#autodj').text('AUTODJ').removeClass('deactivated').addClass('activated');
			} else {
				$('#autodj').text('MANUAL').removeClass('activated').addClass('deactivated');
			}
			nowPlayingMonitor();
		});
	}
	//////////////////////////////////////////////////////////////////////////////////////////////
	function toggleAssisted() {
		$.get("assisted-toggle.php", function(data) {
			if(data.assisted == true) {
				$('#assisted').text('ASSISTED').removeClass('activated').addClass('deactivated');
			} else {
				$('#assisted').text('AUTOMATED').removeClass('deactivated').addClass('activated');
			}
			nowPlayingMonitor();
		});
	}

	function toggleLineInput() {
		$.get("lineinput-toggle.php", function(data) {
			if(data.lineinput == true) {
				$('#lineinput').text('ON-AIR').removeClass('normal').addClass('activated_blink');
			} else {
				$('#lineinput').text('MICROPHONE-OFF').removeClass('activated_blink').addClass('normal');
			}
			nowPlayingMonitor();
		});
	}
	
	function EventsRefresh() {
		$.get("events-refresh.php", function(data) {
			if(status.eventsRefresh == true) {
				;
			}
		});
	}
	
	function clearPlaylist() {
		$.get("clear.php", function(){
			$('#playlistRows .item').remove();
			playlistMonitor();
		});
	}

	function rdjStatus() {
		$.get("status-check.php", function(status) {
			clearTimeout(rdjStatusTimeout);
			rdjStatusTimeout = setTimeout(rdjStatus, 5000);

			if(status.autodj) {
				$('#autodj').text('AUTODJ').removeClass('deactivated').addClass('activated');
			} else {
				$('#autodj').text('MANUAL').removeClass('activated').addClass('deactivated');
			}

			if(status.assisted) {
				$('#assisted').text('ASSISTED').removeClass('activated').addClass('deactivated');
			} else {
				$('#assisted').text('AUTOMATED').removeClass('deactivated').addClass('activated');;
			}
			
			if(status.lineinput) {
				$('#lineinput').text('ON-AIR').removeClass('normal').addClass('activated_blink');
			} else {
				$('#lineinput').text('MICROPHONE-OFF').removeClass('activated_blink').addClass('normal');
			}
			
			if(status.pause) {
				pauseControl = 1;
				$('#pause').removeClass('deactivated').addClass('activated');
			} 
			else {
				pauseControl = 2;
				$('#pause').removeClass('activated').addClass('deactivated');
			}
			
			if(status.eventsOn) {
				$('#events-act').text('Events/OFF').removeClass('normal').addClass('activated_blink');
			} 
			else {
				$('#events-act').text('Events/ON').removeClass('activated_blink').addClass('normal');
			}
		});
	}

    function eventsAction() {
		$.get("events_on-off.php", function(status){
			if(status.eventsOn == true) {
				$('#events-act').text('Events/OFF').removeClass('normal').addClass('activated_blink');
			}
			else {
				$('#events-act').text('Events/ON').removeClass('activated_blink').addClass('normal');
			}
		}	
		);
	}
		
	function playPlaylistTrack(playlistid) {
		clearTimeout(nptime);
		$.get("player-start.php?index="+playlistid, function(status){
			if(status.changed) {
				nowPlayingMonitor();
				nextPlayingMonitor();
			}
		});
	}
	
	function dropPlaylistTrack(playlistid) {
		$.get("item-remove.php?index="+playlistid, function(data){
			if (data.success) {
				playlistMonitor();
			} else {
				alert('Could not remove track');
			}
		});
	}
	
	function playerSTOP() {
		$.get("player-stop.php", function(status){
			if(status.changed) {
				setTimeout(nowPlayingMonitor, 1000);
				stop();
			}						
		});
	}
	
	function playerPAUSE() {
		$.get("player-pause.php", function(status){
			if(status.pause) {
				pauseControl = 1;
				$('#pause').removeClass('deactivated').addClass('activated');
			}
			else {
					pauseControl = 2;
					$('#pause').removeClass('activated').addClass('deactivated');
					setTimeout(nowPlayingMonitor, 1000);
				}
		}	
		);
	}
	
	function playerINTRO() {
		$.get("player-intro.php", function(status){
			if(status.changed) {
				setTimeout(nowPlayingMonitor, 500);
			}						
		}	
		);
	}
	
	function playerRESTART() {
		$.get("player-restart.php", function(status){
			if(status.changed) {
				setTimeout(nowPlayingMonitor, 500);
			}						
		}	
		);
	}
	
///////////////////////////////
//    ####### # #     #
//   #       #   #  #
//  ####    #     # 
// #       #    #   #
//#       #   #      # script
//////////////////////////////	
		
function updateTrackInfoDIV1() {
    var trackInfoElement = document.getElementById('trackInfo');
    var message="";
    if (triggerNowPlaying) {
        message = "<< Now Playing >> " + CurrentArtist; // 17 chars
    } else if (triggerNextTrack) {
        message =  "<< Next track >> " + NextArtist; // 16 chars
    }

    trackInfoElement.textContent = message;
}

setInterval(updateTrackInfoDIV1, 3000); 

function updateTrackInfoDIV2() {
    var trackInfoElement = document.getElementById('trackInfo2');
    var message="";
    if (triggerNowPlaying) {
        message = " -- With -- " + CurrentTitle;
    } else if (triggerNextTrack) {
        message = " -- With -- " + NextTitle;
    }

    trackInfoElement.textContent = message;
}

setInterval(updateTrackInfoDIV2, 3000); 


///////////////////////////////
//    ####### # #     #
//   #       #   #  #
//  ####    #     # 
// #       #    #   #
//#       #   #      # script
//////////////////////////////
	
	function setTimerDurationNP(seconds) {
		var formated = '00:00:00';
		if(seconds >= 0) {
			var time = new Date();
			time.setHours(0);
			time.setMinutes(0);
			time.setSeconds(seconds);
			formated = time.toTimeString().split(" ")[0];
		}
		$('#nowPlayingDuration').text(formated);
	}
	
	function setTimerForward(seconds) {
	  var formated = '00:00:00';
	  if(seconds >= 0) {
		var time = new Date();
		time.setHours(0);
		time.setMinutes(0);
		time.setSeconds(seconds);
		formated = time.toTimeString().split(" ")[0];
	  }
	  $('#countForwardNP').text(formated);
	}
	
	function setTimerRemaining(seconds) {
		var formated = '00:00:00';
		if(seconds >= 0) {
			var time = new Date();
			time.setHours(0);
			time.setMinutes(0);
			time.setSeconds(seconds);
			formated = time.toTimeString().split(" ")[0];
		}
		if(seconds >= 1 && seconds <= 10) 
			$('#countdownNP').addClass('blink');
		if(seconds < 1){
			$('#countdownNP').removeClass('blink');
		}
		$('#countdownNP').text(formated);
	}
	
	function setTimerIntroRemaining(seconds) {
		var formated = '00:00:00';
		if(seconds >= 0) {
			var time = new Date();
			time.setHours(0);
			time.setMinutes(0);
			time.setSeconds(seconds);
			formated = time.toTimeString().split(" ")[0];
		}
		if(seconds >= 1) {
			$('#introNP').addClass('blink');
		}
		if(seconds < 1){
			$('#introNP').removeClass('blink');
		}
		$('#introNP').text(formated);
	}
	
	function setTimerOutroRemaining(seconds) {
		var formated = '00:00:00';
		if(seconds >= 0) {
			var time = new Date();
			time.setHours(0);
			time.setMinutes(0);
			time.setSeconds(seconds);
			formated = time.toTimeString().split(" ")[0];
		}
		if(seconds >= 1 && seconds <= 10) {
			$('#countOutroNP').addClass('blink');
		}
		if(seconds < 1){
			$('#countOutroNP').removeClass('blink');
		}
		$('#countOutroNP').text(formated);
	}
	
	function IntroRemaining() {
		clearTimeout(playingTimer3);
		if (timerIntro > 0)
		{
			timerIntro--;
			playingTimer3 = setTimeout(function () {
			IntroRemaining();
				setTimerIntroRemaining(timerIntro);
			}, 1000);
		}
		else
		{
			clearTimeout(playingTimer3);
			setTimerIntroRemaining(0);
		}
	}
	
	function OutroRemaining() {
		clearTimeout(playingTimer4);
		if (timerOutro > 0)
		{	
			timerOutro--;
			playingTimer4 = setTimeout(function () {		
				OutroRemaining();
				setTimerOutroRemaining(timerOutro);
			}, 1000);
		}
		else
		{
			clearTimeout(playingTimer4);
		}
	}
	
	function Remaining() {
		if(pauseControl === 2){
			clearTimeout(playingTimer);
			timeRemaining = (trackEndsAt - new Date())/1000;
			setTimerRemaining(timeRemaining);
		
			if(timeRemaining < 40){triggerNextTrack = true; triggerNowPlaying = false;}
			else {triggerNextTrack = false; triggerNowPlaying = true;}
		
			if(timeRemaining > 0) {
				playingTimer= setTimeout(Remaining, 1000);
			}
			else
			{
				clearTimeout(playingTimer);
			}
		}
	}
	
	function Forwarding() {
		if(pauseControl === 2){
			clearTimeout(playingTimer2);
			timeForwarding = (new Date() - trackForwardsAt)/1000;
			setTimerForward(timeForwarding);
			if(timeRemaining > 1) {
				playingTimer2 = setTimeout(Forwarding, 1000);
			}
			else
			{
				clearTimeout(playingTimer2);
			}
		}		
	}
	
	function nowPlayingAlbumArt0(AlbumArtFile){
		AlbumArtPath = "./Album-Art/"+AlbumArtFile;
		$('img#nowPlayingAlbumArt').attr('src', AlbumArtPath);
	}
	
	function nextTrackAlbumArt1(AlbumArtFile2){
		AlbumArtPath = "./Album-Art/"+AlbumArtFile2;
		$('img#nextTrackAlbumArt').attr('src', AlbumArtPath);
	}
	
	function nextTrackAlbumArt2(AlbumArtFile3){
		AlbumArtPath = "./Album-Art/"+AlbumArtFile3;
		$('img#nextTrackAlbumArt2').attr('src', AlbumArtPath);
	}
	
	function resetNowPlaying(){
		$('#nowPlayingArtist').text('--------');
		$('#nowPlayingTitle').text('--------');
		$('#nowPlayingDuration').text('--:--:--');
		$('#nowPlayingAlbum').text('--------');
		$('#nowPlayingComposer').text('--------');
		$('#nowPlayingPublisher').text('--------');
		$('#nowPlayingCopyright').text('--------');
		$('#nowPlayingYear').text('----');
		$('#nowPlayingTrackCD').text('--/--');
		$('#clock').text('--:--:---- - --:--');
		$('#introNP').text('--:--:--');
		$('#countOutroNP').text('--:--:--');
		$('#countdownNP').text('--:--:--');
		$('#countForwardNP').text('--:--:--');
	}
})(jQuery);

///////////////////////////////
//    ####### # #     #
//   #       #   #  #
//  ####    #     # 
// #       #    #   #
//#       #   #      # script
//////////////////////////////