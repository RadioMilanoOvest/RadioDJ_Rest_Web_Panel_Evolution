<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard 3.0</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body link="red" alink="red" vlink="red">
<table>
<?php
echo " <tr>" . "\n";
echo "   <td width=\"10%\"><b><center><a href=\"history_songs_body.php\" target=\"framedown3\" style=\"text-decoration: none\">HISTORY SONGS</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"top_songs_body.php\" target=\"framedown3\" style=\"text-decoration: none\">TOP SONGS</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"history_tracks_delete.php\" target=\"framedown3\" style=\"text-decoration: none\">DELETE HISTORY</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"instant_players.html\" target=\"framedxup\" style=\"text-decoration: none\">INSTANT PLAYERS</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"search.php\" target=\"framedxup\" style=\"text-decoration: none\">SEARCH</a></center></b></td>
	   </tr>
	   <tr>
		 <td width=\"10%\"><b><center><a href=\"events_action.html\" target=\"framedxup\" style=\"text-decoration: none\">EVENTS</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"special_thanks.php\" target=\"framedxup\" style=\"text-decoration: none\">SPECIAL THANKS</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"donate.php\" target=\"framedxup\" style=\"text-decoration: none\">DONATE</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"song_details.html\" target=\"framedxup\" style=\"text-decoration: none\">SONGS DETAILS</a></center></b></td>
		 <td width=\"10%\"><b><center><a href=\"catalogue.php\" target=\"framedxup\" style=\"text-decoration: none\">CATALOGUE</a></center></b></td>";
echo " </tr>" . "\n";      
?>
</table>
</body>
</html>