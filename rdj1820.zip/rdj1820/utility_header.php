<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2.0 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard 3.0</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>

<table>
<?php

	echo " <tr>" . "\n";
	echo "  <td class=\"tablecell\" width=\"11%\"><center>Position</center></td>\n";
	echo "  <td class=\"tablecell\" width=\"33%\">Artist</td>\n";
	echo "  <td class=\"tablecell\" width=\"30%\">Songs Available</td>\n";
	echo " </tr>" . "\n";

?>
</table>
</body>
</html>

