<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2.0 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard 3.0</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
<?php

$resDays = 7;				// On how many days to build the top?
$resLimit = 20;				// How many results to display?
//header("Refresh:5");
require_once('serv_inc.php');
date_default_timezone_set($def_timezone);
?>
<table>
<?php

$query = "SELECT `artist`, title, count(*) AS tracks FROM `history` WHERE TIMESTAMPDIFF(DAY, `date_played`, NOW()) <= " . $resDays . " AND `song_type`=0 GROUP BY title ORDER BY tracks DESC LIMIT 0," . $resLimit;
//////////////////////////////////
mysqli_set_charset($con, "utf8");
//////////////////////////////////
$result = mysqli_query($con, $query);
	
if (!$result) {
	echo mysqli_error();
	exit;
}

if (mysqli_num_rows($result) == 0) {
	echo "<p><br><center>".MSG_NORESULTS."</center>";
	exit;
}

$inc = 1;

while($row = mysqli_fetch_assoc($result)) {
	
	echo " <tr>" . "\n";
	echo "  <td class=\"tablecell\" width=\"5%\">" . $inc . ".</td>\n";
	echo "  <td class=\"tablecell\" width=\"14%\">" . $row['artist'] . "</td>\n";
	echo "  <td class=\"tablecell\" width=\"28%\">" . $row['title'] . "</td>\n";
	echo "  <td class=\"tablecell\" width=\"2%\">" . $row['tracks'] . "</td>\n";
	echo " </tr>" . "\n";

	$inc += 1;
}
@mysqli_free_result($con, $result);
mysqli_close($con);
?>
</table>
</body>
</html>

