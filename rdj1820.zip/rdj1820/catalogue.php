<html lang="en">
<head>
	<!-- For use with RadioDJ 1.8.2.0 with REST Server Plugin -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="utf-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>RadioDJ REST DashBoard Evolution</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
	<center>
	<table border="0" width="100%">
	<tr><td colspan=4><h2><i><b>Catalogue</b></i></h2></td></tr>
	<tr><td colspan="7">&nbsp;</td></tr>
	</table>
	</center>
	<form name="input" method="post" action="catalogue.php">
        
    <?php
    require_once('serv_inc.php');
			
	$artist_query = "SELECT DISTINCT artist FROM songs ORDER BY artist ASC";
	
	mysqli_set_charset($con, "utf8");
		
	$result = mysqli_query($con, $artist_query);
	
	echo '<table border ="0" width ="100%">';
	echo '<tr><td><select name="artist" onchange="document.input.submit()">
				  <option value=""> ----- Select artist or band ----- </option>';
		
			while ($row = $result->fetch_assoc()) {
			
				$artist = $row['artist'];
							
					if(strlen($artist) <= 145){ $reduction_length = ceil(strlen($artist) / 0.99); $truncated_artist = substr($artist, 0, $reduction_length);}
					else { $artist = $row['artist']; }
											
					echo '<option value="' . $artist . '">' . $truncated_artist . '</option>';	
			}
	
	echo '<td><!-- <input type="submit" value="Search"> --></td></tr>';
	echo '</table>';
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $selected_artist = $_POST["artist"];
		
		$query = "SELECT artist, title, year, 
				  CASE WHEN song_type = 0 THEN 'Song'
					   WHEN song_type = 1 THEN 'Jingle'
					   WHEN song_type = 6 THEN 'Effect/other'
					   ELSE 'Unknown Audio Type'
				  END AS song_type
				  FROM songs
				  WHERE artist = '$selected_artist'
				  ORDER BY year ASC";
		
			
		mysqli_set_charset($con, "utf8");
				
		$result0 = mysqli_query($con, $query);
		
		echo '<table border="0"  align="left" width="100%">';
		echo '<tr><td colspan="7">&nbsp;</td></tr>';
		echo '<tr><td><i><b>Artist</b></i></td> <td>&nbsp;&nbsp;</td> <td style="text-align: left;"><i><b>Title</b></i></td> <td>&nbsp;&nbsp;</td> <td><i><b>Year</b></i></td> <td>&nbsp;&nbsp;</td> <td><i><b>Audio Type</b></i></td></tr>';
		while ($row = $result0->fetch_assoc()) {
			echo '<tr>';
			echo '<td>' . $row['artist'] . '</td>';
			echo '<td>&nbsp;&nbsp;</td>';
			echo '<td style="text-align: left;">' . $row['title'] . '</td>';
			echo '<td>&nbsp;&nbsp;</td>';
			echo '<td>' . $row['year'] . '</td>';
			echo '<td>&nbsp;&nbsp;</td>';
			echo '<td>' . $row['song_type'] . '</td>';
			echo '</tr>';
		}
		echo '</table>';
    }
	echo '</form>';
    ?>
</body>
</html>