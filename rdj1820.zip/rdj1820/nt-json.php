<?php
session_start();
//sleep(1); // Wait for RadioDJ to update current playing track
require('config.php');
require_once('includes/functions.php');

header('Content-Type: text/json');
// Bust cache. Mainly for IE
header('Cache-Control: no-cache, no-store');
header('Expires: '.date(DATE_RFC822));

$data = array(
	'CurrentArtist' => '-------',
	'CurrentTitle' => '-------',
	'NextArtist' => '-------',
	'NextTitle' => '-------',
	'AlbumArtURI0' => 'no_cover_image.jpg',
	'AlbumArtURI1' => 'no_cover_image.jpg',
	'AlbumArtURI2' => 'no_cover_image.jpg',	
	'AlbumArtURI3' => 'no_cover_image.jpg',
	'AlbumArtURI4' => 'no_cover_image.jpg',
	'error' => null
);

try {
	$xml = simplexml_load_file("http://".$ipAddress.":".$restPort."/p?auth=".$restPassword."");
	
} catch(Exception $ex) {
	$xml = null;
	http_response_code(500);
	$data['error'] = $ex->getMessage();
}

$data = array(
	'isplaying' => true,
	'CurrentArtist' => html_entity_decode(truncate(htmlspecialchars($xml->SongData[0]->Artist), 40)),
	'CurrentTitle' => html_entity_decode(truncate(htmlspecialchars($xml->SongData[0]->Title), 40)),
	'NextArtist' => html_entity_decode(truncate(htmlspecialchars($xml->SongData[1]->Artist), 40)),
	'NextTitle' => html_entity_decode(truncate(htmlspecialchars($xml->SongData[1]->Title), 40)),
	'AlbumArtURI0' => rawurlencode($xml->SongData[0]->AlbumArt), // Now Playing
	'AlbumArtURI1' => rawurlencode($xml->SongData[1]->AlbumArt), // Next Track
	'AlbumArtURI2' => rawurlencode($xml->SongData[2]->AlbumArt), // Next Track 2
	'AlbumArtURI3' => rawurlencode($xml->SongData[3]->AlbumArt), // Next Track 3
	'AlbumArtURI4' => rawurlencode($xml->SongData[4]->AlbumArt)  // Next Track 4
);
exit(json_encode($data));
?>