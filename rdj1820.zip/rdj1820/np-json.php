<?php
session_start();
require('config.php');
require_once('includes/functions.php');

header('Content-Type: text/json');
// Bust cache. Mainly for IE
header('Cache-Control: no-cache, no-store');
header('Expires: '.date(DATE_RFC822));

$data = array(
	'artist' => '-',
	'title' => '-',
	'secondsRemaining' => 0,
	'secondsForwarding' => 0,
	'secondsDuration' => 0,
	'secondsForwarding' => 0,
	'isplaying' => false,
	'OutroRemaining' => '00:00:00',
	'timeRemaining' => '00:00:00',
	'timeElapsed' => '00:00:00',
	'secondsDuration' => '00:00:00',
	'AlbumArtImagePath' => 'no_cover_image.jpg',	
	'error' => null
);

try {
	$xml = simplexml_load_file("http://".$ipAddress.":".$restPort."/np?auth=".$restPassword."");
} catch(Exception $ex) {
	$xml = null;
	http_response_code(500);
	$data['error'] = $ex->getMessage();
}

if( !$xml || (isset($xml->Remaining) && 0 === (int)$xml->Remaining) ) {
	exit(json_encode($data));
}

$secondsDuration = (float)$xml->Duration;
$secondsRemaining = (float)$xml->Remaining;
$introRemaining = (float)$xml->cueIntro;

$OutroRemaining = (float)$xml->cueOutro;
$secondsForwarding = (float)$xml->Elapsed;

if(($introRemaining - $secondsForwarding) < 0) {;} else {$dynamicIntro = ($introRemaining - $secondsForwarding);}
if(($OutroRemaining - $secondsForwarding) < 0) {;} else {$dynamicOutro = ($OutroRemaining - $secondsForwarding);}

$_SESSION['Remaining'] = $secondsRemaining;

$data = array(
	'Artist' => truncate(htmlspecialchars($xml->Artist), 32),
	'Title' => truncate(htmlspecialchars($xml->Title), 32),
	'Year' => htmlspecialchars($xml->Year),
	'AlbumArtImagePath' => rawurlencode($xml->AlbumArt),
	'Composer' => htmlspecialchars($xml->Composer),
	'Publisher' => htmlspecialchars($xml->Publisher), 
	'Copyright' => htmlspecialchars($xml->Copyright),
	'TrackNo' => htmlspecialchars($xml->TrackNo),
	'dynamicIntro' => $dynamicIntro,
	'dynamicOutro' => $dynamicOutro,
	'secondsRemaining' => $secondsRemaining,
	'secondsForwarding' => $secondsForwarding,
	'secondsDuration' => $secondsDuration,
	'isplaying' => true,
	'timeRemaining' => gmdate("H:i:s", round($xml->Remaining)),
);
exit(json_encode($data));
?>