<?php
session_start();
require_once('includes/functions.php');
require_once('serv_inc.php');
require('config.php');
header('Content-type: application/json; charset=utf-8');
header('Content-Type: json');
/* Bust cache. Mainly for IE */
header('Cache-Control: no-cache, no-store');
header('Expires: '.date(DATE_RFC822));

$statusAddSong1 = array(
	'success' => false,
	'changed' => false,
	'error' => null
);

if(isset($_GET['SongID'])){
$id = $_GET['SongID']; // l'errore sql è dovuto al mancato passaggio dell'ID, ma l'errore non è persistente
$_SESSION['SongID'] = $id;
}
else
	echo "id non settato\n ";

try {
	$response = simplexml_load_file("http://".$ipAddress.":".$restPort."/opt?auth=".$restPassword."&command=LoadTrackToTop&arg=". $id ."");
	$statusAddSong1['success'] = ($response == 200);
	$statusAddSong1['changed'] = ($response == 200);
	
} catch (Exception $e) {
	http_response_code(500);
	$statusAddSong1['error'] = $e->getMessage();
}

//exit(json_encode($statusAddSong1));
header("location: response_top.php");
exit();
?>